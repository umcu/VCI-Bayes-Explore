var networks = {"myNetwork.gml": {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.0",
  "target_cytoscapejs_version" : "~2.1",
  "data" : {
    "shared_name" : "myNetwork.gml",
    "name" : "myNetwork.gml",
    "SUID" : 2866,
    "__Annotations" : [ "" ],
    "selected" : true
  },
  "elements" : {
    "nodes" : [ {
      "data" : {
        "id" : "3049",
        "degree_layout" : 43,
        "color" : "lightblue",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "WMH",
        "labelcolor" : "black",
        "shared_name" : "WMH volume",
        "size" : 36.7134995050451,
        "size2" : 7.24608542862732,
        "name" : "WMH",
        "SUID" : 3049,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "MRI"
      },
      "position" : {
        "x" : -102.31503647453337,
        "y" : -951.2913124107472
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3047",
        "degree_layout" : 67,
        "color" : "lightblue",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "PWV",
        "labelcolor" : "black",
        "shared_name" : "PWV",
        "size" : 21.4967201049277,
        "size2" : 7.24608542862732,
        "name" : "PWV",
        "SUID" : 3047,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "MRI"
      },
      "position" : {
        "x" : -102.31503647453155,
        "y" : 1237.5245516455188
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3045",
        "degree_layout" : 2,
        "color" : "lightblue",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_i_ic_cbf_GrayMatter_mean_mL100gmin",
        "labelcolor" : "black",
        "shared_name" : "CBF",
        "size" : 92.7498934864297,
        "size2" : 7.24608542862732,
        "name" : "CBF",
        "SUID" : 3045,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "MRI"
      },
      "position" : {
        "x" : 1495.8668723679425,
        "y" : -1534.5200060044835
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3043",
        "degree_layout" : 13,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_TNFRSF14",
        "labelcolor" : "black",
        "shared_name" : "TNFRSF14",
        "size" : 34.2981376955027,
        "size2" : 7.24608542862732,
        "name" : "T0_TNFRSF14_BLOOD",
        "SUID" : 3043,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : 784.3045636404654,
        "y" : -536.3085715088691
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3041",
        "degree_layout" : 6,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_ITGB2",
        "labelcolor" : "black",
        "shared_name" : "ITGB2",
        "size" : 24.3951542763787,
        "size2" : 7.24608542862732,
        "name" : "T0_ITGB2_BLOOD",
        "SUID" : 3041,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : 231.8457652934112,
        "y" : -908.0275064895693
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3039",
        "degree_layout" : 1,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_TNFR2",
        "labelcolor" : "black",
        "shared_name" : "TNFR",
        "size" : 25.6028351811499,
        "size2" : 7.24608542862732,
        "name" : "T0_TNFR2_BLOOD",
        "SUID" : 3039,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : -494.3254849449205,
        "y" : 1767.8519695363252
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3037",
        "degree_layout" : 12,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_EPHB4",
        "labelcolor" : "black",
        "shared_name" : "EPHB4",
        "size" : 25.8443713621041,
        "size2" : 7.24608542862732,
        "name" : "T0_EPHB4_BLOOD",
        "SUID" : 3037,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : 627.1757903401608,
        "y" : -697.53653520439
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3035",
        "degree_layout" : 8,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_IL2RA",
        "labelcolor" : "black",
        "shared_name" : "IL2RA",
        "size" : 23.9120819144702,
        "size2" : 7.24608542862732,
        "name" : "T0_IL2RA_BLOOD",
        "SUID" : 3035,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : -1117.0444483834303,
        "y" : -189.819444250076
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3033",
        "degree_layout" : 6,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_OPG",
        "labelcolor" : "black",
        "shared_name" : "OPG",
        "size" : 21.0136477430192,
        "size2" : 7.24608542862732,
        "name" : "T0_OPG_BLOOD",
        "SUID" : 3033,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : -1145.7496740955885,
        "y" : 367.0542659031596
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3031",
        "degree_layout" : 12,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_ALCAM",
        "labelcolor" : "black",
        "shared_name" : "ALCAM",
        "size" : 26.5689799049669,
        "size2" : 7.24608542862732,
        "name" : "T0_ALCAM_BLOOD",
        "SUID" : 3031,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : 1007.602889334581,
        "y" : -25.358303101829506
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3029",
        "degree_layout" : 10,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_TFF3",
        "labelcolor" : "black",
        "shared_name" : "TFF3",
        "size" : 21.9797924668362,
        "size2" : 7.24608542862732,
        "name" : "T0_TFF3_BLOOD",
        "SUID" : 3029,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : -817.775644075425,
        "y" : -660.3197118494396
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3027",
        "degree_layout" : 1,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_SELP",
        "labelcolor" : "black",
        "shared_name" : "SELP",
        "size" : 22.7044010096989,
        "size2" : 7.24608542862732,
        "name" : "T0_SELP_BLOOD",
        "SUID" : 3027,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : -117.33693876690336,
        "y" : 1820.7532452392552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3025",
        "degree_layout" : 2,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_CSTB",
        "labelcolor" : "black",
        "shared_name" : "CSTB",
        "size" : 23.1874733716074,
        "size2" : 7.24608542862732,
        "name" : "T0_CSTB_BLOOD",
        "SUID" : 3025,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : -214.6937510636733,
        "y" : 1228.8257284036554
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3023",
        "degree_layout" : 1,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_MCP1",
        "labelcolor" : "black",
        "shared_name" : "MCP1",
        "size" : 23.4290095525617,
        "size2" : 7.24608542862732,
        "name" : "T0_MCP1_BLOOD",
        "SUID" : 3023,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : -307.3360863261163,
        "y" : 1805.0267426976561
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3021",
        "degree_layout" : 5,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_CD163",
        "labelcolor" : "black",
        "shared_name" : "CD163",
        "size" : 25.3612990001956,
        "size2" : 7.24608542862732,
        "name" : "T0_CD163_BLOOD",
        "SUID" : 3021,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : -1077.284037955906,
        "y" : 581.5218959647859
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3019",
        "degree_layout" : 7,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_Gal3",
        "labelcolor" : "black",
        "shared_name" : "Gal3",
        "size" : 20.2890392001565,
        "size2" : 7.24608542862732,
        "name" : "T0_Gal3_BLOOD",
        "SUID" : 3019,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : -1145.749674095591,
        "y" : -80.82102666837591
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3017",
        "degree_layout" : 11,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_GRN",
        "labelcolor" : "black",
        "shared_name" : "GRN",
        "size" : 20.772111562065,
        "size2" : 7.24608542862732,
        "name" : "T0_GRN_BLOOD",
        "SUID" : 3017,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : 440.3898842118606,
        "y" : 1109.4476680724165
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3015",
        "degree_layout" : 12,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_PLC",
        "labelcolor" : "black",
        "shared_name" : "PLC",
        "size" : 19.805966838248,
        "size2" : 7.24608542862732,
        "name" : "T0_PLC_BLOOD",
        "SUID" : 3015,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : -433.8056041998718,
        "y" : -890.8826884393843
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3013",
        "degree_layout" : 12,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_LTBR",
        "labelcolor" : "black",
        "shared_name" : "LTBR",
        "size" : 22.7044010096989,
        "size2" : 7.24608542862732,
        "name" : "T0_LTBR_BLOOD",
        "SUID" : 3013,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : 950.2685590085175,
        "y" : -243.06609405641302
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3011",
        "degree_layout" : 10,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_Notch3",
        "labelcolor" : "black",
        "shared_name" : "Notch3",
        "size" : 25.1197628192414,
        "size2" : 7.24608542862732,
        "name" : "T0_Notch3_BLOOD",
        "SUID" : 3011,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : -731.2240888674498,
        "y" : -732.5240975166662
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3009",
        "degree_layout" : 1,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_TIMP4",
        "labelcolor" : "black",
        "shared_name" : "TIMP4",
        "size" : 24.3951542763787,
        "size2" : 7.24608542862732,
        "name" : "T0_TIMP4_BLOOD",
        "SUID" : 3009,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : 73.21986776842095,
        "y" : 1814.8285141502288
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3007",
        "degree_layout" : 6,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_CNTN1",
        "labelcolor" : "black",
        "shared_name" : "CNTN1",
        "size" : 25.8443713621041,
        "size2" : 7.24608542862732,
        "name" : "T0_CNTN1_BLOOD",
        "SUID" : 3007,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : -1117.0444483834267,
        "y" : 476.0526834848595
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3005",
        "degree_layout" : 10,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_CDH5",
        "labelcolor" : "black",
        "shared_name" : "CDH5",
        "size" : 23.1874733716074,
        "size2" : 7.24608542862732,
        "name" : "T0_CDH5_BLOOD",
        "SUID" : 3005,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : -896.4443383430523,
        "y" : -579.5987011971481
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3003",
        "degree_layout" : 9,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_TLT2",
        "labelcolor" : "black",
        "shared_name" : "TLT2",
        "size" : 21.738256285882,
        "size2" : 7.24608542862732,
        "name" : "T0_TLT2_BLOOD",
        "SUID" : 3003,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : -1077.2840379559107,
        "y" : -295.2886567300029
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3001",
        "degree_layout" : 10,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_TFPI",
        "labelcolor" : "black",
        "shared_name" : "TFPI",
        "size" : 21.0136477430192,
        "size2" : 7.24608542862732,
        "name" : "T0_TFPI_BLOOD",
        "SUID" : 3001,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : -966.3962639406194,
        "y" : -491.2167283537385
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2999",
        "degree_layout" : 3,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_TNFRSF10C",
        "labelcolor" : "black",
        "shared_name" : "TNFRSF10C",
        "size" : 37.6796442288621,
        "size2" : 7.24608542862732,
        "name" : "T0_TNFRSF10C_BLOOD",
        "SUID" : 2999,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : -538.2161025950462,
        "y" : 1134.653086938144
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2997",
        "degree_layout" : 2,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_GDF15",
        "labelcolor" : "black",
        "shared_name" : "GDF15",
        "size" : 25.8443713621041,
        "size2" : 7.24608542862732,
        "name" : "T0_GDF15_BLOOD",
        "SUID" : 2997,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : -433.80560419987046,
        "y" : 1177.1159276741564
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2995",
        "degree_layout" : 1,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_DLK1",
        "labelcolor" : "black",
        "shared_name" : "DLK1",
        "size" : 22.4628648287447,
        "size2" : 7.24608542862732,
        "name" : "T0_DLK1_BLOOD",
        "SUID" : 2995,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : -21.974333624336168,
        "y" : -1534.2658208221449
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2993",
        "degree_layout" : 1,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_SPON1",
        "labelcolor" : "black",
        "shared_name" : "SPON1",
        "size" : 26.3274437240126,
        "size2" : 7.24608542862732,
        "name" : "T0_SPON1_BLOOD",
        "SUID" : 2993,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : 354.7268453942311,
        "y" : 1765.588854753757
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2991",
        "degree_layout" : 1,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_MPO",
        "labelcolor" : "black",
        "shared_name" : "MPO",
        "size" : 21.0136477430192,
        "size2" : 7.24608542862732,
        "name" : "T0_MPO_BLOOD",
        "SUID" : 2991,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : 261.87504628338297,
        "y" : 1787.329012792814
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2989",
        "degree_layout" : 11,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_CXCL16",
        "labelcolor" : "black",
        "shared_name" : "CXCL16",
        "size" : 28.5012693526008,
        "size2" : 7.24608542862732,
        "name" : "T0_CXCL16_BLOOD",
        "SUID" : 2989,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : 905.1314435862905,
        "y" : 632.5818866574773
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2987",
        "degree_layout" : 9,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_IL6RA",
        "labelcolor" : "black",
        "shared_name" : "IL6RA",
        "size" : 23.9120819144702,
        "size2" : 7.24608542862732,
        "name" : "T0_IL6RA_BLOOD",
        "SUID" : 2987,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : 440.38988421185877,
        "y" : -823.2144288376458
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2985",
        "degree_layout" : 5,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_RETN",
        "labelcolor" : "black",
        "shared_name" : "RETN",
        "size" : 23.1874733716074,
        "size2" : 7.24608542862732,
        "name" : "T0_RETN_BLOOD",
        "SUID" : 2985,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : -731.2240888674401,
        "y" : 1018.7573367514451
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2983",
        "degree_layout" : 4,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_TRAP",
        "labelcolor" : "black",
        "shared_name" : "TRAP",
        "size" : 23.1874733716074,
        "size2" : 7.24608542862732,
        "name" : "T0_TRAP_BLOOD",
        "SUID" : 2983,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : -637.7071407358226,
        "y" : 1081.6797129831893
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2981",
        "degree_layout" : 11,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_AXL",
        "labelcolor" : "black",
        "shared_name" : "AXL",
        "size" : 19.5644306572938,
        "size2" : 7.24608542862732,
        "name" : "T0_AXL_BLOOD",
        "SUID" : 2981,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : 627.1757903401624,
        "y" : 983.7697744391608
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2979",
        "degree_layout" : 11,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_IL1RT1",
        "labelcolor" : "black",
        "shared_name" : "IL1RT1",
        "size" : 26.3274437240126,
        "size2" : 7.24608542862732,
        "name" : "T0_IL1RT1_BLOOD",
        "SUID" : 2979,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : 984.5468269805942,
        "y" : 421.92314708895447
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2977",
        "degree_layout" : 5,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_MMP2",
        "labelcolor" : "black",
        "shared_name" : "MMP2",
        "size" : 23.6705457335159,
        "size2" : 7.24608542862732,
        "name" : "T0_MMP2_BLOOD",
        "SUID" : 2977,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : -1026.8899130547877,
        "y" : 682.3439034529893
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2975",
        "degree_layout" : 11,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_FAS",
        "labelcolor" : "black",
        "shared_name" : "FAS",
        "size" : 19.805966838248,
        "size2" : 7.24608542862732,
        "name" : "T0_FAS_BLOOD",
        "SUID" : 2975,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : 784.304563640467,
        "y" : 822.541810743639
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2973",
        "degree_layout" : 1,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_MB",
        "labelcolor" : "black",
        "shared_name" : "MB_BLOOD",
        "size" : 17.3906050287056,
        "size2" : 7.24608542862732,
        "name" : "T0_MB_BLOOD",
        "SUID" : 2973,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : -585.9350146517545,
        "y" : 1741.3607419963041
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2971",
        "degree_layout" : 5,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_TNFSF13B",
        "labelcolor" : "black",
        "shared_name" : "T0_TNFSF13B_BLOOD",
        "size" : 34.0566015145484,
        "size2" : 7.24608542862732,
        "name" : "T0_TNFSF13B_BLOOD",
        "SUID" : 2971,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : -896.4443383430441,
        "y" : 865.8319404319291
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2969",
        "degree_layout" : 5,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_PRTN3",
        "labelcolor" : "black",
        "shared_name" : "T0_PRTN3_BLOOD",
        "size" : 25.8443713621041,
        "size2" : 7.24608542862732,
        "name" : "T0_PRTN3_BLOOD",
        "SUID" : 2969,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : -817.7756440754158,
        "y" : 946.5529510842198
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2967",
        "degree_layout" : 12,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_UPAR",
        "labelcolor" : "black",
        "shared_name" : "T0_UPAR_BLOOD",
        "size" : 23.4290095525617,
        "size2" : 7.24608542862732,
        "name" : "T0_UPAR_BLOOD",
        "SUID" : 2967,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : -214.6937510636751,
        "y" : -942.5924891688833
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2965",
        "degree_layout" : 7,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_OPN",
        "labelcolor" : "black",
        "shared_name" : "T0_OPN_BLOOD",
        "size" : 20.5305753811108,
        "size2" : 7.24608542862732,
        "name" : "T0_OPN_BLOOD",
        "SUID" : 2965,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : -1163.0954325588211,
        "y" : 30.551185673105692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2963",
        "degree_layout" : 1,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_CTSD",
        "labelcolor" : "black",
        "shared_name" : "T0_CTSD_BLOOD",
        "size" : 23.4290095525617,
        "size2" : 7.24608542862732,
        "name" : "T0_CTSD_BLOOD",
        "SUID" : 2963,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : -21.974333624334804,
        "y" : 1820.4990600569163
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2961",
        "degree_layout" : 7,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_PGLYRP1",
        "labelcolor" : "black",
        "shared_name" : "T0_PGLYRP1_BLOOD",
        "size" : 32.1243120669145,
        "size2" : 7.24608542862732,
        "name" : "T0_PGLYRP1_BLOOD",
        "SUID" : 2961,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : -1168.897854418292,
        "y" : 143.11661961739196
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2959",
        "degree_layout" : 1,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_JAMA",
        "labelcolor" : "black",
        "shared_name" : "T0_JAMA_BLOOD",
        "size" : 22.9459371906532,
        "size2" : 7.24608542862732,
        "name" : "T0_JAMA_BLOOD",
        "SUID" : 2959,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : -212.56001653003716,
        "y" : 1815.590248919225
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2957",
        "degree_layout" : 1,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_IL1RT2",
        "labelcolor" : "black",
        "shared_name" : "T0_IL1RT2_BLOOD",
        "size" : 26.3274437240126,
        "size2" : 7.24608542862732,
        "name" : "T0_IL1RT2_BLOOD",
        "SUID" : 2957,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : -401.3591109809854,
        "y" : 1789.0968367207097
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2955",
        "degree_layout" : 6,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_SHPS1",
        "labelcolor" : "black",
        "shared_name" : "T0_SHPS1_BLOOD",
        "size" : 25.8443713621041,
        "size2" : 7.24608542862732,
        "name" : "T0_SHPS1_BLOOD",
        "SUID" : 2955,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : 122.14438455494337,
        "y" : -933.9167336424739
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2953",
        "degree_layout" : 5,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_CCL15",
        "labelcolor" : "black",
        "shared_name" : "T0_CCL15_BLOOD",
        "size" : 25.3612990001956,
        "size2" : 7.24608542862732,
        "name" : "T0_CCL15_BLOOD",
        "SUID" : 2953,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : -966.3962639406121,
        "y" : 777.4499675885199
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2951",
        "degree_layout" : 10,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_uPA",
        "labelcolor" : "black",
        "shared_name" : "T0_uPA_BLOOD",
        "size" : 19.3228944763395,
        "size2" : 7.24608542862732,
        "name" : "T0_uPA_BLOOD",
        "SUID" : 2951,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : -637.7071407358331,
        "y" : -795.4464737484113
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2949",
        "degree_layout" : 6,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_EGFR",
        "labelcolor" : "black",
        "shared_name" : "T0_EGFR_BLOOD",
        "size" : 23.6705457335159,
        "size2" : 7.24608542862732,
        "name" : "T0_EGFR_BLOOD",
        "SUID" : 2949,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : -1163.0954325588198,
        "y" : 255.68205356167846
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2947",
        "degree_layout" : 12,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_IGFBP7",
        "labelcolor" : "black",
        "shared_name" : "T0_IGFBP7_BLOOD",
        "size" : 27.5351246287838,
        "size2" : 7.24608542862732,
        "name" : "T0_IGFBP7_BLOOD",
        "SUID" : 2947,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : 709.8955941024972,
        "y" : -620.9723197769363
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2945",
        "degree_layout" : 12,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_CD93",
        "labelcolor" : "black",
        "shared_name" : "T0_CD93_BLOOD",
        "size" : 22.7044010096989,
        "size2" : 7.24608542862732,
        "name" : "T0_CD93_BLOOD",
        "SUID" : 2945,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : 1019.1923460738526,
        "y" : 199.4740614917746
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2943",
        "degree_layout" : 12,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_IL18BP",
        "labelcolor" : "black",
        "shared_name" : "T0_IL18BP_BLOOD",
        "size" : 26.3274437240126,
        "size2" : 7.24608542862732,
        "name" : "T0_IL18BP_BLOOD",
        "SUID" : 2943,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : 10.362478628665258,
        "y" : 1234.622378551123
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2941",
        "degree_layout" : 1,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_PON3",
        "labelcolor" : "black",
        "shared_name" : "T0_PON3_BLOOD",
        "size" : 23.1874733716074,
        "size2" : 7.24608542862732,
        "name" : "T0_PON3_BLOOD",
        "SUID" : 2941,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : -117.3369387669054,
        "y" : -1534.5200060044835
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2939",
        "degree_layout" : 11,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_CTSZ",
        "labelcolor" : "black",
        "shared_name" : "T0_CTSZ_BLOOD",
        "size" : 22.9459371906532,
        "size2" : 7.24608542862732,
        "name" : "T0_CTSZ_BLOOD",
        "SUID" : 2939,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : 231.84576529341302,
        "y" : 1194.2607457243403
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2937",
        "degree_layout" : 11,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_RARRES2",
        "labelcolor" : "black",
        "shared_name" : "T0_RARRES2_BLOOD",
        "size" : 32.8489206097772,
        "size2" : 7.24608542862732,
        "name" : "T0_RARRES2_BLOOD",
        "SUID" : 2937,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : -538.2161025950579,
        "y" : -848.4198477033667
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2935",
        "degree_layout" : 7,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_ICAM2",
        "labelcolor" : "black",
        "shared_name" : "T0_ICAM2_BLOOD",
        "size" : 24.8782266382871,
        "size2" : 7.24608542862732,
        "name" : "T0_ICAM2_BLOOD",
        "SUID" : 2935,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : 338.30375891773633,
        "y" : -870.9958901059424
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2933",
        "degree_layout" : 9,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_KLK6",
        "labelcolor" : "black",
        "shared_name" : "T0_KLK6_BLOOD",
        "size" : 22.2213286477905,
        "size2" : 7.24608542862732,
        "name" : "T0_KLK6_BLOOD",
        "SUID" : 2933,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : 537.0220028516112,
        "y" : -765.1896180607566
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2931",
        "degree_layout" : 12,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_TNFR1",
        "labelcolor" : "black",
        "shared_name" : "T0_TNFR1_BLOOD",
        "size" : 25.6028351811499,
        "size2" : 7.24608542862732,
        "name" : "T0_TNFR1_BLOOD",
        "SUID" : 2931,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : 849.6139453661835,
        "y" : -444.44274719370037
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2929",
        "degree_layout" : 6,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_IGFBP2",
        "labelcolor" : "black",
        "shared_name" : "T0_IGFBP2_BLOOD",
        "size" : 27.5351246287838,
        "size2" : 7.24608542862732,
        "name" : "T0_IGFBP2_BLOOD",
        "SUID" : 2929,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : 10.362478628663439,
        "y" : -948.3891393163517
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2927",
        "degree_layout" : 2,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_PECAM1",
        "labelcolor" : "black",
        "shared_name" : "T0_PECAM1_BLOOD",
        "size" : 29.708950257372,
        "size2" : 7.24608542862732,
        "name" : "T0_PECAM1_BLOOD",
        "SUID" : 2927,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : -325.5824228075701,
        "y" : 1208.6181185159098
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2925",
        "degree_layout" : 9,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_MEPE",
        "labelcolor" : "black",
        "shared_name" : "T0_MEPE_BLOOD",
        "size" : 23.6705457335159,
        "size2" : 7.24608542862732,
        "name" : "T0_MEPE_BLOOD",
        "SUID" : 2925,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : -1026.8899130547939,
        "y" : -396.1106642182067
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2923",
        "degree_layout" : 1,
        "color" : "firebrick",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "T0_CCL16",
        "labelcolor" : "black",
        "shared_name" : "T0_CCL16_BLOOD",
        "size" : 25.3612990001956,
        "size2" : 7.24608542862732,
        "name" : "T0_CCL16_BLOOD",
        "SUID" : 2923,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "BLOOD"
      },
      "position" : {
        "x" : 167.93827806714353,
        "y" : 1803.7599180257253
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2921",
        "degree_layout" : 6,
        "color" : "beige",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "MMSE",
        "labelcolor" : "black",
        "shared_name" : "T0_MMSE_totaal_E1_C1_CLINICAL",
        "size" : 54.8287130766134,
        "size2" : 7.24608542862732,
        "name" : "MMSE",
        "SUID" : 2921,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "CLINICAL"
      },
      "position" : {
        "x" : 984.5468269805933,
        "y" : -135.6899078541851
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2919",
        "degree_layout" : 1,
        "color" : "beige",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "GEWICHT",
        "labelcolor" : "black",
        "shared_name" : "T0_gewicht_E1_C1_CLINICAL",
        "size" : 43.2349763908097,
        "size2" : 7.24608542862732,
        "name" : "GEWICHT",
        "SUID" : 2919,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "CLINICAL"
      },
      "position" : {
        "x" : 1363.102145581708,
        "y" : -1534.5200060044835
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2917",
        "degree_layout" : 1,
        "color" : "beige",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "MIDDELOMTREK",
        "labelcolor" : "black",
        "shared_name" : "T0_middelomtrek_E1_C1_CLINICAL",
        "size" : 55.5533216194761,
        "size2" : 7.24608542862732,
        "name" : "MIDDELOMTREK",
        "SUID" : 2917,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "CLINICAL"
      },
      "position" : {
        "x" : 1628.6315991541765,
        "y" : -1534.5200060044835
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2915",
        "degree_layout" : 24,
        "color" : "beige",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "INPRENTING_A",
        "labelcolor" : "black",
        "shared_name" : "T0_inprenting_trial_a_E1_C1_CLINICAL",
        "size" : 62.316334686195,
        "size2" : 7.24608542862732,
        "name" : "INPRENTING_A",
        "SUID" : 2915,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "CLINICAL"
      },
      "position" : {
        "x" : 122.14438455494519,
        "y" : 1220.149972877245
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2913",
        "degree_layout" : 33,
        "color" : "beige",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "INPRENTING_B",
        "labelcolor" : "black",
        "shared_name" : "T0_inprenting_trial_b_E1_C1_CLINICAL",
        "size" : 62.5578708671492,
        "size2" : 7.24608542862732,
        "name" : "INPRENTING_B",
        "SUID" : 2913,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "CLINICAL"
      },
      "position" : {
        "x" : 338.3037589177384,
        "y" : 1157.2291293407134
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2911",
        "degree_layout" : 49,
        "color" : "beige",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "INPRENTING_C",
        "labelcolor" : "black",
        "shared_name" : "T0_inprenting_trial_c_E1_C1_CLINICAL",
        "size" : 62.316334686195,
        "size2" : 7.24608542862732,
        "name" : "INPRENTING_C",
        "SUID" : 2911,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "CLINICAL"
      },
      "position" : {
        "x" : 537.0220028516128,
        "y" : 1051.4228572955271
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2909",
        "degree_layout" : 47,
        "color" : "beige",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "INPRENTING_D",
        "labelcolor" : "black",
        "shared_name" : "T0_inprenting_trial_d_E1_C1_CLINICAL",
        "size" : 62.5578708671492,
        "size2" : 7.24608542862732,
        "name" : "INPRENTING_D",
        "SUID" : 2909,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "CLINICAL"
      },
      "position" : {
        "x" : 709.8955941024985,
        "y" : 907.2055590117061
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2907",
        "degree_layout" : 45,
        "color" : "beige",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "INPRENTING_E",
        "labelcolor" : "black",
        "shared_name" : "T0_inprenting_trial_e_E1_C1_CLINICAL",
        "size" : 62.5578708671492,
        "size2" : 7.24608542862732,
        "name" : "INPRENTING_E",
        "SUID" : 2907,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "CLINICAL"
      },
      "position" : {
        "x" : 849.6139453661849,
        "y" : 730.6759864284704
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2905",
        "degree_layout" : 28,
        "color" : "beige",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "TMT_TIJD",
        "labelcolor" : "black",
        "shared_name" : "T0_TMT_a_tijd_E1_C1_CLINICAL",
        "size" : 50.7225980003913,
        "size2" : 7.24608542862732,
        "name" : "TMT_TIJD",
        "SUID" : 2905,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "CLINICAL"
      },
      "position" : {
        "x" : 950.2685590085184,
        "y" : 529.2993332911824
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2903",
        "degree_layout" : 46,
        "color" : "beige",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "UITG_HER",
        "labelcolor" : "black",
        "shared_name" : "T0_uitgestelde_herinnering_E1_C1_CLINICAL",
        "size" : 75.3592884577242,
        "size2" : 7.24608542862732,
        "name" : "UITG_HER",
        "SUID" : 2903,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "CLINICAL"
      },
      "position" : {
        "x" : 1007.6028893345815,
        "y" : 311.5915423365989
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2901",
        "degree_layout" : 1,
        "color" : "beige",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "STROOP_III",
        "labelcolor" : "black",
        "shared_name" : "T0_Stroop_III_E1_C1_CLINICAL",
        "size" : 48.5487723718031,
        "size2" : 7.24608542862732,
        "name" : "STROOP_III",
        "SUID" : 2901,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "CLINICAL"
      },
      "position" : {
        "x" : -212.56001653004012,
        "y" : -1529.3570096844528
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2899",
        "degree_layout" : 18,
        "color" : "beige",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "DIEREN",
        "labelcolor" : "black",
        "shared_name" : "T0_Dieren_E1_C1_CLINICAL",
        "size" : 41.3026869431757,
        "size2" : 7.24608542862732,
        "name" : "DIEREN",
        "SUID" : 2899,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "CLINICAL"
      },
      "position" : {
        "x" : 1019.1923460738526,
        "y" : 86.75917774299478
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2897",
        "degree_layout" : 33,
        "color" : "beige",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "LDST",
        "labelcolor" : "black",
        "shared_name" : "T0_LDST_E1_C1_CLINICAL",
        "size" : 39.8534698574503,
        "size2" : 7.24608542862732,
        "name" : "LDST",
        "SUID" : 2897,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "CLINICAL"
      },
      "position" : {
        "x" : 905.1314435862901,
        "y" : -346.3486474227077
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2895",
        "degree_layout" : 1,
        "color" : "beige",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "4M_TIJD_A",
        "labelcolor" : "black",
        "shared_name" : "T0_4m_tijd_a_E1_C1_CLINICAL",
        "size" : 47.8241638289403,
        "size2" : 7.24608542862732,
        "name" : "4M_TIJD_A",
        "SUID" : 2895,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "CLINICAL"
      },
      "position" : {
        "x" : 1241.7774011581296,
        "y" : -898.3858692134822
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2893",
        "degree_layout" : 7,
        "color" : "beige",
        "shape" : "circle",
        "labelfamily" : "sans",
        "label" : "4M_TIJD_B",
        "labelcolor" : "black",
        "shared_name" : "T0_4m_tijd_b_E1_C1_CLINICAL",
        "size" : 48.0657000098946,
        "size2" : 7.24608542862732,
        "name" : "4M_TIJD_B",
        "SUID" : 2893,
        "labelcex" : 0.572154671347887,
        "selected" : false,
        "group" : "CLINICAL"
      },
      "position" : {
        "x" : -325.5824228075717,
        "y" : -922.384879281138
      },
      "selected" : false
    } ],
    "edges" : [ {
      "data" : {
        "id" : "3913",
        "source" : "3043",
        "target" : "3049",
        "shared_name" : "T0_TNFRSF14 (interacts with) T0_WMHvolume",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#4F0000FF",
        "name" : "T0_TNFRSF14 (interacts with) T0_WMHvolume",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.538873704978601,
        "SUID" : 3913,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3911",
        "source" : "3043",
        "target" : "3047",
        "shared_name" : "T0_TNFRSF14 (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#FF0000FF",
        "name" : "T0_TNFRSF14 (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.730655061162906,
        "SUID" : 3911,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3909",
        "source" : "3041",
        "target" : "3049",
        "shared_name" : "T0_ITGB2 (interacts with) T0_WMHvolume",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#1A0000FF",
        "name" : "T0_ITGB2 (interacts with) T0_WMHvolume",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.502167110365029,
        "SUID" : 3909,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3907",
        "source" : "3041",
        "target" : "3047",
        "shared_name" : "T0_ITGB2 (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#580000FF",
        "name" : "T0_ITGB2 (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.547567826143935,
        "SUID" : 3907,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3905",
        "source" : "3039",
        "target" : "3047",
        "shared_name" : "T0_TNFR2 (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#1A0000FF",
        "name" : "T0_TNFR2 (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.504343267076366,
        "SUID" : 3905,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3903",
        "source" : "3037",
        "target" : "3049",
        "shared_name" : "T0_EPHB4 (interacts with) T0_WMHvolume",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#BE0000FF",
        "name" : "T0_EPHB4 (interacts with) T0_WMHvolume",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.654423167123142,
        "SUID" : 3903,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3901",
        "source" : "3037",
        "target" : "3047",
        "shared_name" : "T0_EPHB4 (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#FF0000FF",
        "name" : "T0_EPHB4 (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.72708429137428,
        "SUID" : 3901,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3899",
        "source" : "3035",
        "target" : "3049",
        "shared_name" : "T0_IL2RA (interacts with) T0_WMHvolume",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#1A0000FF",
        "name" : "T0_IL2RA (interacts with) T0_WMHvolume",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.503454210603356,
        "SUID" : 3899,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3897",
        "source" : "3035",
        "target" : "3047",
        "shared_name" : "T0_IL2RA (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#840000FF",
        "name" : "T0_IL2RA (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.592123440807788,
        "SUID" : 3897,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3895",
        "source" : "3033",
        "target" : "3047",
        "shared_name" : "T0_OPG (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#9D0000FF",
        "name" : "T0_OPG (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.619924397098019,
        "SUID" : 3895,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3893",
        "source" : "3031",
        "target" : "3049",
        "shared_name" : "T0_ALCAM (interacts with) T0_WMHvolume",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#B50000FF",
        "name" : "T0_ALCAM (interacts with) T0_WMHvolume",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.645085017059193,
        "SUID" : 3893,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3891",
        "source" : "3031",
        "target" : "3047",
        "shared_name" : "T0_ALCAM (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#E60000FF",
        "name" : "T0_ALCAM (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.69961451595077,
        "SUID" : 3891,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3889",
        "source" : "3029",
        "target" : "3047",
        "shared_name" : "T0_TFF3 (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#C10000FF",
        "name" : "T0_TFF3 (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.658524544320688,
        "SUID" : 3889,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3887",
        "source" : "3027",
        "target" : "3047",
        "shared_name" : "T0_SELP (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#4A0000FF",
        "name" : "T0_SELP (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.535359573976198,
        "SUID" : 3887,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3885",
        "source" : "3025",
        "target" : "3047",
        "shared_name" : "T0_CSTB (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#9D0000FF",
        "name" : "T0_CSTB (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.618920253298282,
        "SUID" : 3885,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3883",
        "source" : "3023",
        "target" : "3047",
        "shared_name" : "T0_MCP1 (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#630000FF",
        "name" : "T0_MCP1 (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.557586969241895,
        "SUID" : 3883,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3881",
        "source" : "3021",
        "target" : "3047",
        "shared_name" : "T0_CD163 (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#7F0000FF",
        "name" : "T0_CD163 (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.585094467951413,
        "SUID" : 3881,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3879",
        "source" : "3019",
        "target" : "3047",
        "shared_name" : "T0_Gal3 (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#A20000FF",
        "name" : "T0_Gal3 (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.624348864525789,
        "SUID" : 3879,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3877",
        "source" : "3017",
        "target" : "3049",
        "shared_name" : "T0_GRN (interacts with) T0_WMHvolume",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#540000FF",
        "name" : "T0_GRN (interacts with) T0_WMHvolume",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.542693989863106,
        "SUID" : 3877,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3875",
        "source" : "3017",
        "target" : "3047",
        "shared_name" : "T0_GRN (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#CD0000FF",
        "name" : "T0_GRN (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.673462351148225,
        "SUID" : 3875,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3873",
        "source" : "3015",
        "target" : "3049",
        "shared_name" : "T0_PLC (interacts with) T0_WMHvolume",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#630000FF",
        "name" : "T0_PLC (interacts with) T0_WMHvolume",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.559764665402731,
        "SUID" : 3873,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3871",
        "source" : "3015",
        "target" : "3047",
        "shared_name" : "T0_PLC (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#FF0000FF",
        "name" : "T0_PLC (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.728732261146497,
        "SUID" : 3871,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3869",
        "source" : "3013",
        "target" : "3049",
        "shared_name" : "T0_LTBR (interacts with) T0_WMHvolume",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#A50000FF",
        "name" : "T0_LTBR (interacts with) T0_WMHvolume",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.626493231313117,
        "SUID" : 3869,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3867",
        "source" : "3013",
        "target" : "3047",
        "shared_name" : "T0_LTBR (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#F60000FF",
        "name" : "T0_LTBR (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.719462197448163,
        "SUID" : 3867,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3865",
        "source" : "3011",
        "target" : "3049",
        "shared_name" : "T0_Notch3 (interacts with) T0_WMHvolume",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#580000FF",
        "name" : "T0_Notch3 (interacts with) T0_WMHvolume",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.547551895268425,
        "SUID" : 3865,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3863",
        "source" : "3011",
        "target" : "3047",
        "shared_name" : "T0_Notch3 (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#A50000FF",
        "name" : "T0_Notch3 (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.628769466551223,
        "SUID" : 3863,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3861",
        "source" : "3009",
        "target" : "3047",
        "shared_name" : "T0_TIMP4 (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#450000FF",
        "name" : "T0_TIMP4 (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.529245864663505,
        "SUID" : 3861,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3859",
        "source" : "3007",
        "target" : "3049",
        "shared_name" : "T0_CNTN1 (interacts with) T0_WMHvolume",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#630000FF",
        "name" : "T0_CNTN1 (interacts with) T0_WMHvolume",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.556575553293378,
        "SUID" : 3859,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3857",
        "source" : "3007",
        "target" : "3047",
        "shared_name" : "T0_CNTN1 (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#1A0000FF",
        "name" : "T0_CNTN1 (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.501783839109462,
        "SUID" : 3857,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3855",
        "source" : "3005",
        "target" : "3049",
        "shared_name" : "T0_CDH5 (interacts with) T0_WMHvolume",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#710000FF",
        "name" : "T0_CDH5 (interacts with) T0_WMHvolume",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.573080416605534,
        "SUID" : 3855,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3853",
        "source" : "3005",
        "target" : "3047",
        "shared_name" : "T0_CDH5 (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#950000FF",
        "name" : "T0_CDH5 (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.609051260066422,
        "SUID" : 3853,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3851",
        "source" : "3003",
        "target" : "3049",
        "shared_name" : "T0_TLT2 (interacts with) T0_WMHvolume",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#540000FF",
        "name" : "T0_TLT2 (interacts with) T0_WMHvolume",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.541888570290013,
        "SUID" : 3851,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3849",
        "source" : "3003",
        "target" : "3047",
        "shared_name" : "T0_TLT2 (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#840000FF",
        "name" : "T0_TLT2 (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.588759425149885,
        "SUID" : 3849,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3847",
        "source" : "3001",
        "target" : "3049",
        "shared_name" : "T0_TFPI (interacts with) T0_WMHvolume",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#840000FF",
        "name" : "T0_TFPI (interacts with) T0_WMHvolume",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.589950399100239,
        "SUID" : 3847,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3845",
        "source" : "3001",
        "target" : "3047",
        "shared_name" : "T0_TFPI (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#9D0000FF",
        "name" : "T0_TFPI (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.615986337503238,
        "SUID" : 3845,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3843",
        "source" : "2999",
        "target" : "3047",
        "shared_name" : "T0_TNFRSF10C (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#3C0000FF",
        "name" : "T0_TNFRSF10C (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.521130578877424,
        "SUID" : 3843,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3841",
        "source" : "2997",
        "target" : "3047",
        "shared_name" : "T0_GDF15 (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#910000FF",
        "name" : "T0_GDF15 (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.604418664285393,
        "SUID" : 3841,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3839",
        "source" : "2995",
        "target" : "3049",
        "shared_name" : "T0_DLK1 (interacts with) T0_WMHvolume",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#320000FF",
        "name" : "T0_DLK1 (interacts with) T0_WMHvolume",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.510281438401756,
        "SUID" : 3839,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3837",
        "source" : "2993",
        "target" : "3047",
        "shared_name" : "T0_SPON1 (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#400000FF",
        "name" : "T0_SPON1 (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.523829074643835,
        "SUID" : 3837,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3835",
        "source" : "2991",
        "target" : "3047",
        "shared_name" : "T0_MPO (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#320000FF",
        "name" : "T0_MPO (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.509978270297845,
        "SUID" : 3835,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3833",
        "source" : "2989",
        "target" : "3049",
        "shared_name" : "T0_CXCL16 (interacts with) T0_WMHvolume",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#540000FF",
        "name" : "T0_CXCL16 (interacts with) T0_WMHvolume",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.541920690191725,
        "SUID" : 3833,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3831",
        "source" : "2989",
        "target" : "3047",
        "shared_name" : "T0_CXCL16 (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#D20000FF",
        "name" : "T0_CXCL16 (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.678826589149786,
        "SUID" : 3831,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3829",
        "source" : "2987",
        "target" : "3049",
        "shared_name" : "T0_IL6RA (interacts with) T0_WMHvolume",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#840000FF",
        "name" : "T0_IL6RA (interacts with) T0_WMHvolume",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.588170105912095,
        "SUID" : 3829,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3827",
        "source" : "2987",
        "target" : "3047",
        "shared_name" : "T0_IL6RA (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#580000FF",
        "name" : "T0_IL6RA (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.548957826659971,
        "SUID" : 3827,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3825",
        "source" : "2985",
        "target" : "3047",
        "shared_name" : "T0_RETN (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#710000FF",
        "name" : "T0_RETN (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.572083594676013,
        "SUID" : 3825,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3823",
        "source" : "2983",
        "target" : "3047",
        "shared_name" : "T0_TRAP (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#4F0000FF",
        "name" : "T0_TRAP (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.540228637971124,
        "SUID" : 3823,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3821",
        "source" : "2981",
        "target" : "3049",
        "shared_name" : "T0_AXL (interacts with) T0_WMHvolume",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#B10000FF",
        "name" : "T0_AXL (interacts with) T0_WMHvolume",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.642310099684922,
        "SUID" : 3821,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3819",
        "source" : "2981",
        "target" : "3047",
        "shared_name" : "T0_AXL (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#AE0000FF",
        "name" : "T0_AXL (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.638093091372492,
        "SUID" : 3819,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3817",
        "source" : "2979",
        "target" : "3049",
        "shared_name" : "T0_IL1RT1 (interacts with) T0_WMHvolume",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#990000FF",
        "name" : "T0_IL1RT1 (interacts with) T0_WMHvolume",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.612611737492086,
        "SUID" : 3817,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3815",
        "source" : "2979",
        "target" : "3047",
        "shared_name" : "T0_IL1RT1 (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#C60000FF",
        "name" : "T0_IL1RT1 (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.66302996466572,
        "SUID" : 3815,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3813",
        "source" : "2977",
        "target" : "3047",
        "shared_name" : "T0_MMP2 (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#7B0000FF",
        "name" : "T0_MMP2 (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.578874179505653,
        "SUID" : 3813,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3811",
        "source" : "2975",
        "target" : "3049",
        "shared_name" : "T0_FAS (interacts with) T0_WMHvolume",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#5D0000FF",
        "name" : "T0_FAS (interacts with) T0_WMHvolume",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.552301090596014,
        "SUID" : 3811,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3809",
        "source" : "2975",
        "target" : "3047",
        "shared_name" : "T0_FAS (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#CD0000FF",
        "name" : "T0_FAS (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.673202072740365,
        "SUID" : 3809,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3807",
        "source" : "2973",
        "target" : "3047",
        "shared_name" : "T0_MB (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#2D0000FF",
        "name" : "T0_MB (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.506452462341864,
        "SUID" : 3807,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3805",
        "source" : "2971",
        "target" : "3047",
        "shared_name" : "T0_TNFSF13B (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#6C0000FF",
        "name" : "T0_TNFSF13B (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.568595698410214,
        "SUID" : 3805,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3803",
        "source" : "2969",
        "target" : "3047",
        "shared_name" : "T0_PRTN3 (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#630000FF",
        "name" : "T0_PRTN3 (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.555417503458673,
        "SUID" : 3803,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3801",
        "source" : "2967",
        "target" : "3049",
        "shared_name" : "T0_UPAR (interacts with) T0_WMHvolume",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#1A0000FF",
        "name" : "T0_UPAR (interacts with) T0_WMHvolume",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.502962933057611,
        "SUID" : 3801,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3799",
        "source" : "2967",
        "target" : "3047",
        "shared_name" : "T0_UPAR (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#EA0000FF",
        "name" : "T0_UPAR (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.705945643069366,
        "SUID" : 3799,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3797",
        "source" : "2965",
        "target" : "3047",
        "shared_name" : "T0_OPN (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#A50000FF",
        "name" : "T0_OPN (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.627427607940859,
        "SUID" : 3797,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3795",
        "source" : "2963",
        "target" : "3047",
        "shared_name" : "T0_CTSD (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#400000FF",
        "name" : "T0_CTSD (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.526382589572025,
        "SUID" : 3795,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3793",
        "source" : "2961",
        "target" : "3047",
        "shared_name" : "T0_PGLYRP1 (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#8D0000FF",
        "name" : "T0_PGLYRP1 (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.59867020052184,
        "SUID" : 3793,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3791",
        "source" : "2959",
        "target" : "3047",
        "shared_name" : "T0_JAMA (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#370000FF",
        "name" : "T0_JAMA (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.516816930375005,
        "SUID" : 3791,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3789",
        "source" : "2957",
        "target" : "3047",
        "shared_name" : "T0_IL1RT2 (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#4A0000FF",
        "name" : "T0_IL1RT2 (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.535495364115506,
        "SUID" : 3789,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3787",
        "source" : "2955",
        "target" : "3049",
        "shared_name" : "T0_SHPS1 (interacts with) T0_WMHvolume",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#4A0000FF",
        "name" : "T0_SHPS1 (interacts with) T0_WMHvolume",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.534811481814174,
        "SUID" : 3787,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3785",
        "source" : "2955",
        "target" : "3047",
        "shared_name" : "T0_SHPS1 (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#400000FF",
        "name" : "T0_SHPS1 (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.526576177288693,
        "SUID" : 3785,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3783",
        "source" : "2953",
        "target" : "3047",
        "shared_name" : "T0_CCL15 (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#7B0000FF",
        "name" : "T0_CCL15 (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.58273071628863,
        "SUID" : 3783,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3781",
        "source" : "2951",
        "target" : "3049",
        "shared_name" : "T0_uPA (interacts with) T0_WMHvolume",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#7F0000FF",
        "name" : "T0_uPA (interacts with) T0_WMHvolume",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.584538251429131,
        "SUID" : 3781,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3779",
        "source" : "2951",
        "target" : "3047",
        "shared_name" : "T0_uPA (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#910000FF",
        "name" : "T0_uPA (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.605876847642656,
        "SUID" : 3779,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3777",
        "source" : "2949",
        "target" : "3049",
        "shared_name" : "T0_EGFR (interacts with) T0_WMHvolume",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#7B0000FF",
        "name" : "T0_EGFR (interacts with) T0_WMHvolume",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.582112937412872,
        "SUID" : 3777,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3775",
        "source" : "2949",
        "target" : "3047",
        "shared_name" : "T0_EGFR (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#2D0000FF",
        "name" : "T0_EGFR (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.507988613115494,
        "SUID" : 3775,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3773",
        "source" : "2947",
        "target" : "3049",
        "shared_name" : "T0_IGFBP7 (interacts with) T0_WMHvolume",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#450000FF",
        "name" : "T0_IGFBP7 (interacts with) T0_WMHvolume",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.528881776663428,
        "SUID" : 3773,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3771",
        "source" : "2947",
        "target" : "3047",
        "shared_name" : "T0_IGFBP7 (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#F60000FF",
        "name" : "T0_IGFBP7 (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.720490223476774,
        "SUID" : 3771,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3769",
        "source" : "2945",
        "target" : "3049",
        "shared_name" : "T0_CD93 (interacts with) T0_WMHvolume",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#D60000FF",
        "name" : "T0_CD93 (interacts with) T0_WMHvolume",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.682666485054903,
        "SUID" : 3769,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3767",
        "source" : "2945",
        "target" : "3047",
        "shared_name" : "T0_CD93 (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#EA0000FF",
        "name" : "T0_CD93 (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.70345178864909,
        "SUID" : 3767,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3765",
        "source" : "2943",
        "target" : "3049",
        "shared_name" : "T0_IL18BP (interacts with) T0_WMHvolume",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#AE0000FF",
        "name" : "T0_IL18BP (interacts with) T0_WMHvolume",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.63540899399289,
        "SUID" : 3765,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3763",
        "source" : "2943",
        "target" : "3047",
        "shared_name" : "T0_IL18BP (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#FF0000FF",
        "name" : "T0_IL18BP (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.728282647296048,
        "SUID" : 3763,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3761",
        "source" : "2941",
        "target" : "3049",
        "shared_name" : "T0_PON3 (interacts with) T0_WMHvolume",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#910000FF",
        "name" : "T0_PON3 (interacts with) T0_WMHvolume",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.6025582623805,
        "SUID" : 3761,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3759",
        "source" : "2939",
        "target" : "3049",
        "shared_name" : "T0_CTSZ (interacts with) T0_WMHvolume",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#2D0000FF",
        "name" : "T0_CTSZ (interacts with) T0_WMHvolume",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.507497498726541,
        "SUID" : 3759,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3757",
        "source" : "2939",
        "target" : "3047",
        "shared_name" : "T0_CTSZ (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#BE0000FF",
        "name" : "T0_CTSZ (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.652686026885168,
        "SUID" : 3757,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3755",
        "source" : "2937",
        "target" : "3047",
        "shared_name" : "T0_RARRES2 (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#DE0000FF",
        "name" : "T0_RARRES2 (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.691581894775122,
        "SUID" : 3755,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3753",
        "source" : "2935",
        "target" : "3049",
        "shared_name" : "T0_ICAM2 (interacts with) T0_WMHvolume",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#450000FF",
        "name" : "T0_ICAM2 (interacts with) T0_WMHvolume",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.529959648536405,
        "SUID" : 3753,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3751",
        "source" : "2935",
        "target" : "3047",
        "shared_name" : "T0_ICAM2 (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#6C0000FF",
        "name" : "T0_ICAM2 (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.564955444211828,
        "SUID" : 3751,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3749",
        "source" : "2933",
        "target" : "3049",
        "shared_name" : "T0_KLK6 (interacts with) T0_WMHvolume",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#710000FF",
        "name" : "T0_KLK6 (interacts with) T0_WMHvolume",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.570771951221434,
        "SUID" : 3749,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3747",
        "source" : "2933",
        "target" : "3047",
        "shared_name" : "T0_KLK6 (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#840000FF",
        "name" : "T0_KLK6 (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.590284811026289,
        "SUID" : 3747,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3745",
        "source" : "2931",
        "target" : "3049",
        "shared_name" : "T0_TNFR1 (interacts with) T0_WMHvolume",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#710000FF",
        "name" : "T0_TNFR1 (interacts with) T0_WMHvolume",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.572000682951048,
        "SUID" : 3745,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3743",
        "source" : "2931",
        "target" : "3047",
        "shared_name" : "T0_TNFR1 (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#FA0000FF",
        "name" : "T0_TNFR1 (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.725323551972546,
        "SUID" : 3743,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3741",
        "source" : "2929",
        "target" : "3049",
        "shared_name" : "T0_IGFBP2 (interacts with) T0_WMHvolume",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#4F0000FF",
        "name" : "T0_IGFBP2 (interacts with) T0_WMHvolume",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.539464900078525,
        "SUID" : 3741,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3739",
        "source" : "2929",
        "target" : "3047",
        "shared_name" : "T0_IGFBP2 (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#1A0000FF",
        "name" : "T0_IGFBP2 (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.502874085486678,
        "SUID" : 3739,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3737",
        "source" : "2927",
        "target" : "3047",
        "shared_name" : "T0_PECAM1 (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#750000FF",
        "name" : "T0_PECAM1 (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.576460780189645,
        "SUID" : 3737,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3735",
        "source" : "2925",
        "target" : "3049",
        "shared_name" : "T0_MEPE (interacts with) T0_WMHvolume",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#710000FF",
        "name" : "T0_MEPE (interacts with) T0_WMHvolume",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.572840859131895,
        "SUID" : 3735,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3733",
        "source" : "2925",
        "target" : "3047",
        "shared_name" : "T0_MEPE (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#840000FF",
        "name" : "T0_MEPE (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.589881322607505,
        "SUID" : 3733,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3731",
        "source" : "2923",
        "target" : "3047",
        "shared_name" : "T0_CCL16 (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#320000FF",
        "name" : "T0_CCL16 (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.512330645876502,
        "SUID" : 3731,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3729",
        "source" : "2921",
        "target" : "3049",
        "shared_name" : "T0_MMSE_totaal_E1_C1 (interacts with) T0_WMHvolume",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#003900FF",
        "name" : "T0_MMSE_totaal_E1_C1 (interacts with) T0_WMHvolume",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.539820512259003,
        "SUID" : 3729,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3727",
        "source" : "2921",
        "target" : "3037",
        "shared_name" : "T0_MMSE_totaal_E1_C1 (interacts with) T0_EPHB4",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002E00FF",
        "name" : "T0_MMSE_totaal_E1_C1 (interacts with) T0_EPHB4",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.525411477590428,
        "SUID" : 3727,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3725",
        "source" : "2921",
        "target" : "3031",
        "shared_name" : "T0_MMSE_totaal_E1_C1 (interacts with) T0_ALCAM",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002300FF",
        "name" : "T0_MMSE_totaal_E1_C1 (interacts with) T0_ALCAM",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.51337812587727,
        "SUID" : 3725,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3723",
        "source" : "2921",
        "target" : "3013",
        "shared_name" : "T0_MMSE_totaal_E1_C1 (interacts with) T0_LTBR",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002000FF",
        "name" : "T0_MMSE_totaal_E1_C1 (interacts with) T0_LTBR",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.509199152435184,
        "SUID" : 3723,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3721",
        "source" : "2921",
        "target" : "2945",
        "shared_name" : "T0_MMSE_totaal_E1_C1 (interacts with) T0_CD93",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#003600FF",
        "name" : "T0_MMSE_totaal_E1_C1 (interacts with) T0_CD93",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.53348960914756,
        "SUID" : 3721,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3719",
        "source" : "2921",
        "target" : "2943",
        "shared_name" : "T0_MMSE_totaal_E1_C1 (interacts with) T0_IL18BP",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002700FF",
        "name" : "T0_MMSE_totaal_E1_C1 (interacts with) T0_IL18BP",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.51606931162906,
        "SUID" : 3719,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3717",
        "source" : "2919",
        "target" : "3045",
        "shared_name" : "T0_gewicht_E1_C1 (interacts with) T0_i_ic_cbf_GrayMatter_mean_mL100gmin",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#008800FF",
        "name" : "T0_gewicht_E1_C1 (interacts with) T0_i_ic_cbf_GrayMatter_mean_mL100gmin",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.628474904510646,
        "SUID" : 3717,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3715",
        "source" : "2917",
        "target" : "3045",
        "shared_name" : "T0_middelomtrek_E1_C1 (interacts with) T0_i_ic_cbf_GrayMatter_mean_mL100gmin",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#007D00FF",
        "name" : "T0_middelomtrek_E1_C1 (interacts with) T0_i_ic_cbf_GrayMatter_mean_mL100gmin",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.617024216902943,
        "SUID" : 3715,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3713",
        "source" : "2915",
        "target" : "3049",
        "shared_name" : "T0_inprenting_trial_a_E1_C1 (interacts with) T0_WMHvolume",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002300FF",
        "name" : "T0_inprenting_trial_a_E1_C1 (interacts with) T0_WMHvolume",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.512462041260263,
        "SUID" : 3713,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3711",
        "source" : "2915",
        "target" : "3047",
        "shared_name" : "T0_inprenting_trial_a_E1_C1 (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002300FF",
        "name" : "T0_inprenting_trial_a_E1_C1 (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.513693252491279,
        "SUID" : 3711,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3709",
        "source" : "2915",
        "target" : "3043",
        "shared_name" : "T0_inprenting_trial_a_E1_C1 (interacts with) T0_TNFRSF14",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#005100FF",
        "name" : "T0_inprenting_trial_a_E1_C1 (interacts with) T0_TNFRSF14",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.570716211460348,
        "SUID" : 3709,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3707",
        "source" : "2915",
        "target" : "3037",
        "shared_name" : "T0_inprenting_trial_a_E1_C1 (interacts with) T0_EPHB4",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#006800FF",
        "name" : "T0_inprenting_trial_a_E1_C1 (interacts with) T0_EPHB4",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.600105543531355,
        "SUID" : 3707,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3705",
        "source" : "2915",
        "target" : "3031",
        "shared_name" : "T0_inprenting_trial_a_E1_C1 (interacts with) T0_ALCAM",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#005700FF",
        "name" : "T0_inprenting_trial_a_E1_C1 (interacts with) T0_ALCAM",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.581622485126459,
        "SUID" : 3705,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3703",
        "source" : "2915",
        "target" : "3029",
        "shared_name" : "T0_inprenting_trial_a_E1_C1 (interacts with) T0_TFF3",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002700FF",
        "name" : "T0_inprenting_trial_a_E1_C1 (interacts with) T0_TFF3",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.515840114274483,
        "SUID" : 3703,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3701",
        "source" : "2915",
        "target" : "3017",
        "shared_name" : "T0_inprenting_trial_a_E1_C1 (interacts with) T0_GRN",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#003900FF",
        "name" : "T0_inprenting_trial_a_E1_C1 (interacts with) T0_GRN",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.538567898956173,
        "SUID" : 3701,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3699",
        "source" : "2915",
        "target" : "3015",
        "shared_name" : "T0_inprenting_trial_a_E1_C1 (interacts with) T0_PLC",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#005400FF",
        "name" : "T0_inprenting_trial_a_E1_C1 (interacts with) T0_PLC",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.575288546516968,
        "SUID" : 3699,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3697",
        "source" : "2915",
        "target" : "3013",
        "shared_name" : "T0_inprenting_trial_a_E1_C1 (interacts with) T0_LTBR",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#005F00FF",
        "name" : "T0_inprenting_trial_a_E1_C1 (interacts with) T0_LTBR",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.588077831660941,
        "SUID" : 3697,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3695",
        "source" : "2915",
        "target" : "3011",
        "shared_name" : "T0_inprenting_trial_a_E1_C1 (interacts with) T0_Notch3",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002700FF",
        "name" : "T0_inprenting_trial_a_E1_C1 (interacts with) T0_Notch3",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.513955658243333,
        "SUID" : 3695,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3693",
        "source" : "2915",
        "target" : "3005",
        "shared_name" : "T0_inprenting_trial_a_E1_C1 (interacts with) T0_CDH5",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002300FF",
        "name" : "T0_inprenting_trial_a_E1_C1 (interacts with) T0_CDH5",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.509464156285893,
        "SUID" : 3693,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3691",
        "source" : "2915",
        "target" : "3001",
        "shared_name" : "T0_inprenting_trial_a_E1_C1 (interacts with) T0_TFPI",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002700FF",
        "name" : "T0_inprenting_trial_a_E1_C1 (interacts with) T0_TFPI",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.518081830606817,
        "SUID" : 3691,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3689",
        "source" : "2915",
        "target" : "2989",
        "shared_name" : "T0_inprenting_trial_a_E1_C1 (interacts with) T0_CXCL16",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#003900FF",
        "name" : "T0_inprenting_trial_a_E1_C1 (interacts with) T0_CXCL16",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.541470173292211,
        "SUID" : 3689,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3687",
        "source" : "2915",
        "target" : "2981",
        "shared_name" : "T0_inprenting_trial_a_E1_C1 (interacts with) T0_AXL",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#003C00FF",
        "name" : "T0_inprenting_trial_a_E1_C1 (interacts with) T0_AXL",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.545166533393898,
        "SUID" : 3687,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3685",
        "source" : "2915",
        "target" : "2979",
        "shared_name" : "T0_inprenting_trial_a_E1_C1 (interacts with) T0_IL1RT1",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#004200FF",
        "name" : "T0_inprenting_trial_a_E1_C1 (interacts with) T0_IL1RT1",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.551551036946176,
        "SUID" : 3685,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3683",
        "source" : "2915",
        "target" : "2975",
        "shared_name" : "T0_inprenting_trial_a_E1_C1 (interacts with) T0_FAS",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#003900FF",
        "name" : "T0_inprenting_trial_a_E1_C1 (interacts with) T0_FAS",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.541032650754047,
        "SUID" : 3683,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3681",
        "source" : "2915",
        "target" : "2967",
        "shared_name" : "T0_inprenting_trial_a_E1_C1 (interacts with) T0_UPAR",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#004000FF",
        "name" : "T0_inprenting_trial_a_E1_C1 (interacts with) T0_UPAR",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.546599862200996,
        "SUID" : 3681,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3679",
        "source" : "2915",
        "target" : "2951",
        "shared_name" : "T0_inprenting_trial_a_E1_C1 (interacts with) T0_uPA",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002300FF",
        "name" : "T0_inprenting_trial_a_E1_C1 (interacts with) T0_uPA",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.510741770375882,
        "SUID" : 3679,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3677",
        "source" : "2915",
        "target" : "2947",
        "shared_name" : "T0_inprenting_trial_a_E1_C1 (interacts with) T0_IGFBP7",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#004A00FF",
        "name" : "T0_inprenting_trial_a_E1_C1 (interacts with) T0_IGFBP7",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.562097065916637,
        "SUID" : 3677,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3675",
        "source" : "2915",
        "target" : "2945",
        "shared_name" : "T0_inprenting_trial_a_E1_C1 (interacts with) T0_CD93",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#006300FF",
        "name" : "T0_inprenting_trial_a_E1_C1 (interacts with) T0_CD93",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.594081781525286,
        "SUID" : 3675,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3673",
        "source" : "2915",
        "target" : "2943",
        "shared_name" : "T0_inprenting_trial_a_E1_C1 (interacts with) T0_IL18BP",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#006300FF",
        "name" : "T0_inprenting_trial_a_E1_C1 (interacts with) T0_IL18BP",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.595623824558464,
        "SUID" : 3673,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3671",
        "source" : "2915",
        "target" : "2939",
        "shared_name" : "T0_inprenting_trial_a_E1_C1 (interacts with) T0_CTSZ",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002700FF",
        "name" : "T0_inprenting_trial_a_E1_C1 (interacts with) T0_CTSZ",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.516928375592654,
        "SUID" : 3671,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3669",
        "source" : "2915",
        "target" : "2937",
        "shared_name" : "T0_inprenting_trial_a_E1_C1 (interacts with) T0_RARRES2",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#003200FF",
        "name" : "T0_inprenting_trial_a_E1_C1 (interacts with) T0_RARRES2",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.529617611701479,
        "SUID" : 3669,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3667",
        "source" : "2915",
        "target" : "2931",
        "shared_name" : "T0_inprenting_trial_a_E1_C1 (interacts with) T0_TNFR1",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#005400FF",
        "name" : "T0_inprenting_trial_a_E1_C1 (interacts with) T0_TNFR1",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.57664208101304,
        "SUID" : 3667,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3665",
        "source" : "2913",
        "target" : "3049",
        "shared_name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_WMHvolume",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#005100FF",
        "name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_WMHvolume",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.570293477263009,
        "SUID" : 3665,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3663",
        "source" : "2913",
        "target" : "3047",
        "shared_name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#003900FF",
        "name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.540918245944943,
        "SUID" : 3663,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3661",
        "source" : "2913",
        "target" : "3043",
        "shared_name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_TNFRSF14",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#006800FF",
        "name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_TNFRSF14",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.598083596461384,
        "SUID" : 3661,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3659",
        "source" : "2913",
        "target" : "3037",
        "shared_name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_EPHB4",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#009200FF",
        "name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_EPHB4",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.638222913449744,
        "SUID" : 3659,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3657",
        "source" : "2913",
        "target" : "3035",
        "shared_name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_IL2RA",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002000FF",
        "name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_IL2RA",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.509009237034177,
        "SUID" : 3657,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3655",
        "source" : "2913",
        "target" : "3031",
        "shared_name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_ALCAM",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#007D00FF",
        "name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_ALCAM",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.619716723731869,
        "SUID" : 3655,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3653",
        "source" : "2913",
        "target" : "3029",
        "shared_name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_TFF3",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#003900FF",
        "name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_TFF3",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.541001357299292,
        "SUID" : 3653,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3651",
        "source" : "2913",
        "target" : "3019",
        "shared_name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_Gal3",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002A00FF",
        "name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_Gal3",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.521260044954554,
        "SUID" : 3651,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3649",
        "source" : "2913",
        "target" : "3017",
        "shared_name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_GRN",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#004E00FF",
        "name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_GRN",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.568029421752563,
        "SUID" : 3649,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3647",
        "source" : "2913",
        "target" : "3015",
        "shared_name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_PLC",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#006D00FF",
        "name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_PLC",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.604638402363179,
        "SUID" : 3647,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3645",
        "source" : "2913",
        "target" : "3013",
        "shared_name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_LTBR",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#008300FF",
        "name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_LTBR",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.623855271709441,
        "SUID" : 3645,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3643",
        "source" : "2913",
        "target" : "3011",
        "shared_name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_Notch3",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#003C00FF",
        "name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_Notch3",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.545226080783166,
        "SUID" : 3643,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3641",
        "source" : "2913",
        "target" : "3005",
        "shared_name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_CDH5",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#003C00FF",
        "name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_CDH5",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.543686252342123,
        "SUID" : 3641,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3639",
        "source" : "2913",
        "target" : "3003",
        "shared_name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_TLT2",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002A00FF",
        "name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_TLT2",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.521163890449641,
        "SUID" : 3639,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3637",
        "source" : "2913",
        "target" : "3001",
        "shared_name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_TFPI",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#004200FF",
        "name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_TFPI",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.55364625030416,
        "SUID" : 3637,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3635",
        "source" : "2913",
        "target" : "2989",
        "shared_name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_CXCL16",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#005100FF",
        "name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_CXCL16",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.570697065011533,
        "SUID" : 3635,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3633",
        "source" : "2913",
        "target" : "2987",
        "shared_name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_IL6RA",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002700FF",
        "name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_IL6RA",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.516143398138417,
        "SUID" : 3633,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3631",
        "source" : "2913",
        "target" : "2981",
        "shared_name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_AXL",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#005B00FF",
        "name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_AXL",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.584879413072036,
        "SUID" : 3631,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3629",
        "source" : "2913",
        "target" : "2979",
        "shared_name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_IL1RT1",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#005F00FF",
        "name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_IL1RT1",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.587769251740529,
        "SUID" : 3629,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3627",
        "source" : "2913",
        "target" : "2975",
        "shared_name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_FAS",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#005100FF",
        "name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_FAS",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.571386841780824,
        "SUID" : 3627,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3625",
        "source" : "2913",
        "target" : "2967",
        "shared_name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_UPAR",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#005100FF",
        "name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_UPAR",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.571412892950008,
        "SUID" : 3625,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3623",
        "source" : "2913",
        "target" : "2965",
        "shared_name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_OPN",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#001200FF",
        "name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_OPN",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.503368259156511,
        "SUID" : 3623,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3621",
        "source" : "2913",
        "target" : "2961",
        "shared_name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_PGLYRP1",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002000FF",
        "name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_PGLYRP1",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.50483694813244,
        "SUID" : 3621,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3619",
        "source" : "2913",
        "target" : "2951",
        "shared_name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_uPA",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#003C00FF",
        "name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_uPA",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.546115749058729,
        "SUID" : 3619,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3617",
        "source" : "2913",
        "target" : "2947",
        "shared_name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_IGFBP7",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#005F00FF",
        "name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_IGFBP7",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.588853933914355,
        "SUID" : 3617,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3615",
        "source" : "2913",
        "target" : "2945",
        "shared_name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_CD93",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#009200FF",
        "name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_CD93",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.635520081731706,
        "SUID" : 3615,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3613",
        "source" : "2913",
        "target" : "2943",
        "shared_name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_IL18BP",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#008D00FF",
        "name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_IL18BP",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.631953630587674,
        "SUID" : 3613,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3611",
        "source" : "2913",
        "target" : "2939",
        "shared_name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_CTSZ",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#003C00FF",
        "name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_CTSZ",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.543781506018076,
        "SUID" : 3611,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3609",
        "source" : "2913",
        "target" : "2937",
        "shared_name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_RARRES2",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#004200FF",
        "name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_RARRES2",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.551943516219481,
        "SUID" : 3609,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3607",
        "source" : "2913",
        "target" : "2935",
        "shared_name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_ICAM2",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#001200FF",
        "name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_ICAM2",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.503729261538616,
        "SUID" : 3607,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3605",
        "source" : "2913",
        "target" : "2933",
        "shared_name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_KLK6",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#003600FF",
        "name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_KLK6",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.532526795601266,
        "SUID" : 3605,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3603",
        "source" : "2913",
        "target" : "2931",
        "shared_name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_TNFR1",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#007200FF",
        "name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_TNFR1",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.607222621668885,
        "SUID" : 3603,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3601",
        "source" : "2913",
        "target" : "2925",
        "shared_name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_MEPE",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#003600FF",
        "name" : "T0_inprenting_trial_b_E1_C1 (interacts with) T0_MEPE",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.533058791910434,
        "SUID" : 3601,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3599",
        "source" : "2911",
        "target" : "3049",
        "shared_name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_WMHvolume",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#006D00FF",
        "name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_WMHvolume",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.60423422316886,
        "SUID" : 3599,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3597",
        "source" : "2911",
        "target" : "3047",
        "shared_name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#006300FF",
        "name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.592873580561181,
        "SUID" : 3597,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3595",
        "source" : "2911",
        "target" : "3043",
        "shared_name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_TNFRSF14",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#00AD00FF",
        "name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_TNFRSF14",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.657485961877301,
        "SUID" : 3595,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3593",
        "source" : "2911",
        "target" : "3041",
        "shared_name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_ITGB2",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002E00FF",
        "name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_ITGB2",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.526813424180655,
        "SUID" : 3593,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3591",
        "source" : "2911",
        "target" : "3037",
        "shared_name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_EPHB4",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#00D800FF",
        "name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_EPHB4",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.695236036574258,
        "SUID" : 3591,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3589",
        "source" : "2911",
        "target" : "3035",
        "shared_name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_IL2RA",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#004700FF",
        "name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_IL2RA",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.555963466833693,
        "SUID" : 3589,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3587",
        "source" : "2911",
        "target" : "3033",
        "shared_name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_OPG",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#004000FF",
        "name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_OPG",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.546969669361859,
        "SUID" : 3587,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3585",
        "source" : "2911",
        "target" : "3031",
        "shared_name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_ALCAM",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#00BE00FF",
        "name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_ALCAM",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.674302585251658,
        "SUID" : 3585,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3583",
        "source" : "2911",
        "target" : "3029",
        "shared_name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_TFF3",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#006300FF",
        "name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_TFF3",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.594443928705079,
        "SUID" : 3583,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3581",
        "source" : "2911",
        "target" : "3025",
        "shared_name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_CSTB",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002300FF",
        "name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_CSTB",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.51274031252239,
        "SUID" : 3581,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3579",
        "source" : "2911",
        "target" : "3021",
        "shared_name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_CD163",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#003200FF",
        "name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_CD163",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.529468759395908,
        "SUID" : 3579,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3577",
        "source" : "2911",
        "target" : "3019",
        "shared_name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_Gal3",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#005100FF",
        "name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_Gal3",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.571522812804505,
        "SUID" : 3577,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3575",
        "source" : "2911",
        "target" : "3017",
        "shared_name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_GRN",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#008300FF",
        "name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_GRN",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.621965027976493,
        "SUID" : 3575,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3573",
        "source" : "2911",
        "target" : "3015",
        "shared_name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_PLC",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#00B300FF",
        "name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_PLC",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.663488233238836,
        "SUID" : 3573,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3571",
        "source" : "2911",
        "target" : "3013",
        "shared_name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_LTBR",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#00C800FF",
        "name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_LTBR",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.680644917636757,
        "SUID" : 3571,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3569",
        "source" : "2911",
        "target" : "3011",
        "shared_name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_Notch3",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#006300FF",
        "name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_Notch3",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.594856465380842,
        "SUID" : 3569,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3567",
        "source" : "2911",
        "target" : "3007",
        "shared_name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_CNTN1",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002700FF",
        "name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_CNTN1",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.516176596463755,
        "SUID" : 3567,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3565",
        "source" : "2911",
        "target" : "3005",
        "shared_name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_CDH5",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#005F00FF",
        "name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_CDH5",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.59100187787076,
        "SUID" : 3565,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3563",
        "source" : "2911",
        "target" : "3003",
        "shared_name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_TLT2",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#004E00FF",
        "name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_TLT2",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.567117964975226,
        "SUID" : 3563,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3561",
        "source" : "2911",
        "target" : "3001",
        "shared_name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_TFPI",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#006800FF",
        "name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_TFPI",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.601316925208274,
        "SUID" : 3561,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3559",
        "source" : "2911",
        "target" : "2999",
        "shared_name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_TNFRSF10C",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002000FF",
        "name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_TNFRSF10C",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.505456194260547,
        "SUID" : 3559,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3557",
        "source" : "2911",
        "target" : "2989",
        "shared_name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_CXCL16",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#008800FF",
        "name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_CXCL16",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.625152781547441,
        "SUID" : 3557,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3555",
        "source" : "2911",
        "target" : "2987",
        "shared_name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_IL6RA",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#004700FF",
        "name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_IL6RA",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.557518294876989,
        "SUID" : 3555,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3553",
        "source" : "2911",
        "target" : "2985",
        "shared_name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_RETN",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#003900FF",
        "name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_RETN",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.537448314527082,
        "SUID" : 3553,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3551",
        "source" : "2911",
        "target" : "2983",
        "shared_name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_TRAP",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002000FF",
        "name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_TRAP",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.509086965369657,
        "SUID" : 3551,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3549",
        "source" : "2911",
        "target" : "2981",
        "shared_name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_AXL",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#008D00FF",
        "name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_AXL",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.633707022150775,
        "SUID" : 3549,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3547",
        "source" : "2911",
        "target" : "2979",
        "shared_name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_IL1RT1",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#009700FF",
        "name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_IL1RT1",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.639478311299979,
        "SUID" : 3547,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3545",
        "source" : "2911",
        "target" : "2977",
        "shared_name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_MMP2",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002E00FF",
        "name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_MMP2",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.526382466717904,
        "SUID" : 3545,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3543",
        "source" : "2911",
        "target" : "2975",
        "shared_name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_FAS",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#008800FF",
        "name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_FAS",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.625127255298053,
        "SUID" : 3543,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3541",
        "source" : "2911",
        "target" : "2971",
        "shared_name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_TNFSF13B",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#003200FF",
        "name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_TNFSF13B",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.529218613655688,
        "SUID" : 3541,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3539",
        "source" : "2911",
        "target" : "2969",
        "shared_name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_PRTN3",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002E00FF",
        "name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_PRTN3",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.525307236120472,
        "SUID" : 3539,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3537",
        "source" : "2911",
        "target" : "2967",
        "shared_name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_UPAR",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#008800FF",
        "name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_UPAR",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.629120502235606,
        "SUID" : 3537,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3535",
        "source" : "2911",
        "target" : "2965",
        "shared_name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_OPN",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#004200FF",
        "name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_OPN",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.554876247131937,
        "SUID" : 3535,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3533",
        "source" : "2911",
        "target" : "2961",
        "shared_name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_PGLYRP1",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#004200FF",
        "name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_PGLYRP1",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.552787999928143,
        "SUID" : 3533,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3531",
        "source" : "2911",
        "target" : "2955",
        "shared_name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_SHPS1",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002E00FF",
        "name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_SHPS1",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.524604867196626,
        "SUID" : 3531,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3529",
        "source" : "2911",
        "target" : "2953",
        "shared_name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_CCL15",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002A00FF",
        "name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_CCL15",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.520473704615871,
        "SUID" : 3529,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3527",
        "source" : "2911",
        "target" : "2951",
        "shared_name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_uPA",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#006300FF",
        "name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_uPA",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.5929282225957,
        "SUID" : 3527,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3525",
        "source" : "2911",
        "target" : "2949",
        "shared_name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_EGFR",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#003200FF",
        "name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_EGFR",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.529025360412298,
        "SUID" : 3525,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3523",
        "source" : "2911",
        "target" : "2947",
        "shared_name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_IGFBP7",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#009D00FF",
        "name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_IGFBP7",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.647474210437899,
        "SUID" : 3523,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3521",
        "source" : "2911",
        "target" : "2945",
        "shared_name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_CD93",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#00D300FF",
        "name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_CD93",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.689800726795903,
        "SUID" : 3521,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3519",
        "source" : "2911",
        "target" : "2943",
        "shared_name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_IL18BP",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#00D300FF",
        "name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_IL18BP",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.689417569881788,
        "SUID" : 3519,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3517",
        "source" : "2911",
        "target" : "2939",
        "shared_name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_CTSZ",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#006300FF",
        "name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_CTSZ",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.596380948909917,
        "SUID" : 3517,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3515",
        "source" : "2911",
        "target" : "2937",
        "shared_name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_RARRES2",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#007200FF",
        "name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_RARRES2",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.608859239977741,
        "SUID" : 3515,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3513",
        "source" : "2911",
        "target" : "2935",
        "shared_name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_ICAM2",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#004000FF",
        "name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_ICAM2",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.547648132546593,
        "SUID" : 3513,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3511",
        "source" : "2911",
        "target" : "2933",
        "shared_name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_KLK6",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#005400FF",
        "name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_KLK6",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.578111893482973,
        "SUID" : 3511,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3509",
        "source" : "2911",
        "target" : "2931",
        "shared_name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_TNFR1",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#00B300FF",
        "name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_TNFR1",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.665533362691457,
        "SUID" : 3509,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3507",
        "source" : "2911",
        "target" : "2929",
        "shared_name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_IGFBP2",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002300FF",
        "name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_IGFBP2",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.510948259455504,
        "SUID" : 3507,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3505",
        "source" : "2911",
        "target" : "2927",
        "shared_name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_PECAM1",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002000FF",
        "name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_PECAM1",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.505873629842828,
        "SUID" : 3505,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3503",
        "source" : "2911",
        "target" : "2925",
        "shared_name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_MEPE",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#005700FF",
        "name" : "T0_inprenting_trial_c_E1_C1 (interacts with) T0_MEPE",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.578569057105939,
        "SUID" : 3503,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3501",
        "source" : "2909",
        "target" : "3049",
        "shared_name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_WMHvolume",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#008800FF",
        "name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_WMHvolume",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.627058198415585,
        "SUID" : 3501,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3499",
        "source" : "2909",
        "target" : "3047",
        "shared_name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#005B00FF",
        "name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.587078614207744,
        "SUID" : 3499,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3497",
        "source" : "2909",
        "target" : "3043",
        "shared_name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_TNFRSF14",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#00A300FF",
        "name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_TNFRSF14",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.648362013689962,
        "SUID" : 3497,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3495",
        "source" : "2909",
        "target" : "3041",
        "shared_name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_ITGB2",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002E00FF",
        "name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_ITGB2",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.526795275204785,
        "SUID" : 3495,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3493",
        "source" : "2909",
        "target" : "3037",
        "shared_name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_EPHB4",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#00D800FF",
        "name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_EPHB4",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.694353562308215,
        "SUID" : 3493,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3491",
        "source" : "2909",
        "target" : "3035",
        "shared_name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_IL2RA",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#004200FF",
        "name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_IL2RA",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.553199066787443,
        "SUID" : 3491,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3489",
        "source" : "2909",
        "target" : "3033",
        "shared_name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_OPG",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#003900FF",
        "name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_OPG",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.53705245175414,
        "SUID" : 3489,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3487",
        "source" : "2909",
        "target" : "3031",
        "shared_name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_ALCAM",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#00BE00FF",
        "name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_ALCAM",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.674520617261815,
        "SUID" : 3487,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3485",
        "source" : "2909",
        "target" : "3029",
        "shared_name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_TFF3",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#005B00FF",
        "name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_TFF3",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.586593933548974,
        "SUID" : 3485,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3483",
        "source" : "2909",
        "target" : "3021",
        "shared_name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_CD163",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002A00FF",
        "name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_CD163",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.522756123062308,
        "SUID" : 3483,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3481",
        "source" : "2909",
        "target" : "3019",
        "shared_name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_Gal3",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#004E00FF",
        "name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_Gal3",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.565666820734851,
        "SUID" : 3481,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3479",
        "source" : "2909",
        "target" : "3017",
        "shared_name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_GRN",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#007D00FF",
        "name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_GRN",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.616745791970514,
        "SUID" : 3479,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3477",
        "source" : "2909",
        "target" : "3015",
        "shared_name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_PLC",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#00A800FF",
        "name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_PLC",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.655935598389237,
        "SUID" : 3477,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3475",
        "source" : "2909",
        "target" : "3013",
        "shared_name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_LTBR",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#00C300FF",
        "name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_LTBR",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.678310361257895,
        "SUID" : 3475,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3473",
        "source" : "2909",
        "target" : "3011",
        "shared_name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_Notch3",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#006300FF",
        "name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_Notch3",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.592818418972474,
        "SUID" : 3473,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3471",
        "source" : "2909",
        "target" : "3007",
        "shared_name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_CNTN1",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002A00FF",
        "name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_CNTN1",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.522845779796192,
        "SUID" : 3471,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3469",
        "source" : "2909",
        "target" : "3005",
        "shared_name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_CDH5",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#005F00FF",
        "name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_CDH5",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.591989295184658,
        "SUID" : 3469,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3467",
        "source" : "2909",
        "target" : "3003",
        "shared_name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_TLT2",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#004E00FF",
        "name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_TLT2",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.567233364844672,
        "SUID" : 3467,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3465",
        "source" : "2909",
        "target" : "3001",
        "shared_name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_TFPI",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#006D00FF",
        "name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_TFPI",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.603033054900624,
        "SUID" : 3465,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3463",
        "source" : "2909",
        "target" : "2999",
        "shared_name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_TNFRSF10C",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002000FF",
        "name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_TNFRSF10C",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.506254936728847,
        "SUID" : 3463,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3461",
        "source" : "2909",
        "target" : "2989",
        "shared_name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_CXCL16",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#007D00FF",
        "name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_CXCL16",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.619538531019872,
        "SUID" : 3461,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3459",
        "source" : "2909",
        "target" : "2987",
        "shared_name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_IL6RA",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#004A00FF",
        "name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_IL6RA",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.563376645045468,
        "SUID" : 3459,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3457",
        "source" : "2909",
        "target" : "2985",
        "shared_name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_RETN",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#003600FF",
        "name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_RETN",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.534837682902827,
        "SUID" : 3457,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3455",
        "source" : "2909",
        "target" : "2983",
        "shared_name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_TRAP",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002000FF",
        "name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_TRAP",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.506934868312194,
        "SUID" : 3455,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3453",
        "source" : "2909",
        "target" : "2981",
        "shared_name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_AXL",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#009200FF",
        "name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_AXL",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.637647818715239,
        "SUID" : 3453,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3451",
        "source" : "2909",
        "target" : "2979",
        "shared_name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_IL1RT1",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#009700FF",
        "name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_IL1RT1",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.639772317932496,
        "SUID" : 3451,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3449",
        "source" : "2909",
        "target" : "2977",
        "shared_name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_MMP2",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002A00FF",
        "name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_MMP2",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.520249981765102,
        "SUID" : 3449,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3447",
        "source" : "2909",
        "target" : "2975",
        "shared_name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_FAS",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#008300FF",
        "name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_FAS",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.620590908588494,
        "SUID" : 3447,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3445",
        "source" : "2909",
        "target" : "2971",
        "shared_name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_TNFSF13B",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002E00FF",
        "name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_TNFSF13B",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.525632792878845,
        "SUID" : 3445,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3443",
        "source" : "2909",
        "target" : "2969",
        "shared_name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_PRTN3",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002E00FF",
        "name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_PRTN3",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.523476223100261,
        "SUID" : 3443,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3441",
        "source" : "2909",
        "target" : "2967",
        "shared_name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_UPAR",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#007D00FF",
        "name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_UPAR",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.619078378569575,
        "SUID" : 3441,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3439",
        "source" : "2909",
        "target" : "2965",
        "shared_name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_OPN",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#003C00FF",
        "name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_OPN",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.545096403947356,
        "SUID" : 3439,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3437",
        "source" : "2909",
        "target" : "2961",
        "shared_name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_PGLYRP1",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#004000FF",
        "name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_PGLYRP1",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.548127586951814,
        "SUID" : 3437,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3435",
        "source" : "2909",
        "target" : "2955",
        "shared_name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_SHPS1",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#003200FF",
        "name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_SHPS1",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.528186761946351,
        "SUID" : 3435,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3433",
        "source" : "2909",
        "target" : "2953",
        "shared_name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_CCL15",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002300FF",
        "name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_CCL15",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.512416273017828,
        "SUID" : 3433,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3431",
        "source" : "2909",
        "target" : "2951",
        "shared_name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_uPA",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#006300FF",
        "name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_uPA",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.59491234723936,
        "SUID" : 3431,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3429",
        "source" : "2909",
        "target" : "2949",
        "shared_name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_EGFR",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#003900FF",
        "name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_EGFR",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.537070882584853,
        "SUID" : 3429,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3427",
        "source" : "2909",
        "target" : "2947",
        "shared_name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_IGFBP7",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#009200FF",
        "name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_IGFBP7",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.638304137080441,
        "SUID" : 3427,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3425",
        "source" : "2909",
        "target" : "2945",
        "shared_name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_CD93",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#00D300FF",
        "name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_CD93",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.692381113928188,
        "SUID" : 3425,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3423",
        "source" : "2909",
        "target" : "2943",
        "shared_name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_IL18BP",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#00CE00FF",
        "name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_IL18BP",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.687140055338319,
        "SUID" : 3423,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3421",
        "source" : "2909",
        "target" : "2939",
        "shared_name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_CTSZ",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#005F00FF",
        "name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_CTSZ",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.590042775946199,
        "SUID" : 3421,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3419",
        "source" : "2909",
        "target" : "2937",
        "shared_name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_RARRES2",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#006800FF",
        "name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_RARRES2",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.597528538529621,
        "SUID" : 3419,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3417",
        "source" : "2909",
        "target" : "2935",
        "shared_name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_ICAM2",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#004000FF",
        "name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_ICAM2",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.548451057744556,
        "SUID" : 3417,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3415",
        "source" : "2909",
        "target" : "2933",
        "shared_name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_KLK6",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#005700FF",
        "name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_KLK6",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.580133498862677,
        "SUID" : 3415,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3413",
        "source" : "2909",
        "target" : "2931",
        "shared_name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_TNFR1",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#00AD00FF",
        "name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_TNFR1",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.659046318690065,
        "SUID" : 3413,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3411",
        "source" : "2909",
        "target" : "2929",
        "shared_name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_IGFBP2",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002700FF",
        "name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_IGFBP2",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.51636130612348,
        "SUID" : 3411,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3409",
        "source" : "2909",
        "target" : "2925",
        "shared_name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_MEPE",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#005700FF",
        "name" : "T0_inprenting_trial_d_E1_C1 (interacts with) T0_MEPE",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.580759834932297,
        "SUID" : 3409,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3407",
        "source" : "2907",
        "target" : "3049",
        "shared_name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_WMHvolume",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#006D00FF",
        "name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_WMHvolume",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.605920448607397,
        "SUID" : 3407,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3405",
        "source" : "2907",
        "target" : "3047",
        "shared_name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#005100FF",
        "name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.573389089080147,
        "SUID" : 3405,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3403",
        "source" : "2907",
        "target" : "3043",
        "shared_name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_TNFRSF14",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#009200FF",
        "name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_TNFRSF14",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.633855259854959,
        "SUID" : 3403,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3401",
        "source" : "2907",
        "target" : "3041",
        "shared_name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_ITGB2",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002300FF",
        "name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_ITGB2",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.513347698135158,
        "SUID" : 3401,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3399",
        "source" : "2907",
        "target" : "3037",
        "shared_name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_EPHB4",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#00C300FF",
        "name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_EPHB4",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.676821518299472,
        "SUID" : 3399,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3397",
        "source" : "2907",
        "target" : "3035",
        "shared_name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_IL2RA",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#003900FF",
        "name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_IL2RA",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.539694035645885,
        "SUID" : 3397,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3395",
        "source" : "2907",
        "target" : "3033",
        "shared_name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_OPG",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002E00FF",
        "name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_OPG",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.525566129460363,
        "SUID" : 3395,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3393",
        "source" : "2907",
        "target" : "3031",
        "shared_name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_ALCAM",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#00AD00FF",
        "name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_ALCAM",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.657247849193435,
        "SUID" : 3393,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3391",
        "source" : "2907",
        "target" : "3029",
        "shared_name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_TFF3",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#005100FF",
        "name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_TFF3",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.573378310876408,
        "SUID" : 3391,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3389",
        "source" : "2907",
        "target" : "3021",
        "shared_name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_CD163",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002300FF",
        "name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_CD163",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.510915158711378,
        "SUID" : 3389,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3387",
        "source" : "2907",
        "target" : "3019",
        "shared_name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_Gal3",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#004200FF",
        "name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_Gal3",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.552537748527131,
        "SUID" : 3387,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3385",
        "source" : "2907",
        "target" : "3017",
        "shared_name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_GRN",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#006D00FF",
        "name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_GRN",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.602169419367139,
        "SUID" : 3385,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3383",
        "source" : "2907",
        "target" : "3015",
        "shared_name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_PLC",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#009700FF",
        "name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_PLC",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.640882562461007,
        "SUID" : 3383,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3381",
        "source" : "2907",
        "target" : "3013",
        "shared_name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_LTBR",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#00B300FF",
        "name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_LTBR",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.661514092559347,
        "SUID" : 3381,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3379",
        "source" : "2907",
        "target" : "3011",
        "shared_name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_Notch3",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#005400FF",
        "name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_Notch3",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.578138585244227,
        "SUID" : 3379,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3377",
        "source" : "2907",
        "target" : "3007",
        "shared_name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_CNTN1",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002000FF",
        "name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_CNTN1",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.507997186055992,
        "SUID" : 3377,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3375",
        "source" : "2907",
        "target" : "3005",
        "shared_name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_CDH5",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#005400FF",
        "name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_CDH5",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.576651162868082,
        "SUID" : 3375,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3373",
        "source" : "2907",
        "target" : "3003",
        "shared_name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_TLT2",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#004200FF",
        "name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_TLT2",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.552723213184986,
        "SUID" : 3373,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3371",
        "source" : "2907",
        "target" : "3001",
        "shared_name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_TFPI",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#005B00FF",
        "name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_TFPI",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.587249264527315,
        "SUID" : 3371,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3369",
        "source" : "2907",
        "target" : "2989",
        "shared_name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_CXCL16",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#006D00FF",
        "name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_CXCL16",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.604979560031222,
        "SUID" : 3369,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3367",
        "source" : "2907",
        "target" : "2987",
        "shared_name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_IL6RA",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#004000FF",
        "name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_IL6RA",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.547675200608985,
        "SUID" : 3367,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3365",
        "source" : "2907",
        "target" : "2985",
        "shared_name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_RETN",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002A00FF",
        "name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_RETN",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.521766973559288,
        "SUID" : 3365,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3363",
        "source" : "2907",
        "target" : "2981",
        "shared_name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_AXL",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#008300FF",
        "name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_AXL",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.620480520416889,
        "SUID" : 3363,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3361",
        "source" : "2907",
        "target" : "2979",
        "shared_name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_IL1RT1",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#008300FF",
        "name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_IL1RT1",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.623369780775075,
        "SUID" : 3361,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3359",
        "source" : "2907",
        "target" : "2977",
        "shared_name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_MMP2",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002000FF",
        "name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_MMP2",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.508342718820036,
        "SUID" : 3359,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3357",
        "source" : "2907",
        "target" : "2975",
        "shared_name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_FAS",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#006D00FF",
        "name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_FAS",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.605762985523254,
        "SUID" : 3357,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3355",
        "source" : "2907",
        "target" : "2971",
        "shared_name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_TNFSF13B",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002300FF",
        "name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_TNFSF13B",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.513016140971426,
        "SUID" : 3355,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3353",
        "source" : "2907",
        "target" : "2969",
        "shared_name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_PRTN3",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002300FF",
        "name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_PRTN3",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.51052053753095,
        "SUID" : 3353,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3351",
        "source" : "2907",
        "target" : "2967",
        "shared_name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_UPAR",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#006D00FF",
        "name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_UPAR",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.60552558612733,
        "SUID" : 3351,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3349",
        "source" : "2907",
        "target" : "2965",
        "shared_name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_OPN",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#003600FF",
        "name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_OPN",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.533373828245375,
        "SUID" : 3349,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3347",
        "source" : "2907",
        "target" : "2961",
        "shared_name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_PGLYRP1",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#003600FF",
        "name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_PGLYRP1",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.535177869232101,
        "SUID" : 3347,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3345",
        "source" : "2907",
        "target" : "2955",
        "shared_name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_SHPS1",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002700FF",
        "name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_SHPS1",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.513895141904626,
        "SUID" : 3345,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3343",
        "source" : "2907",
        "target" : "2953",
        "shared_name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_CCL15",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#001200FF",
        "name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_CCL15",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.501141354716549,
        "SUID" : 3343,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3341",
        "source" : "2907",
        "target" : "2951",
        "shared_name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_uPA",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#005700FF",
        "name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_uPA",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.579275730818092,
        "SUID" : 3341,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3339",
        "source" : "2907",
        "target" : "2949",
        "shared_name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_EGFR",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002A00FF",
        "name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_EGFR",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.521549949164195,
        "SUID" : 3339,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3337",
        "source" : "2907",
        "target" : "2947",
        "shared_name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_IGFBP7",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#008300FF",
        "name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_IGFBP7",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.624064568863033,
        "SUID" : 3337,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3335",
        "source" : "2907",
        "target" : "2945",
        "shared_name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_CD93",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#00BE00FF",
        "name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_CD93",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.67412173354939,
        "SUID" : 3335,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3333",
        "source" : "2907",
        "target" : "2943",
        "shared_name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_IL18BP",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#00B800FF",
        "name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_IL18BP",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.670105510806853,
        "SUID" : 3333,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3331",
        "source" : "2907",
        "target" : "2939",
        "shared_name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_CTSZ",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#005400FF",
        "name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_CTSZ",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.57639955671945,
        "SUID" : 3331,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3329",
        "source" : "2907",
        "target" : "2937",
        "shared_name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_RARRES2",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#005B00FF",
        "name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_RARRES2",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.58481541232668,
        "SUID" : 3329,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3327",
        "source" : "2907",
        "target" : "2935",
        "shared_name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_ICAM2",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#003600FF",
        "name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_ICAM2",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.534266102947315,
        "SUID" : 3327,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3325",
        "source" : "2907",
        "target" : "2933",
        "shared_name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_KLK6",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#004E00FF",
        "name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_KLK6",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.564865840963934,
        "SUID" : 3325,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3323",
        "source" : "2907",
        "target" : "2931",
        "shared_name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_TNFR1",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#009D00FF",
        "name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_TNFR1",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.643674536448526,
        "SUID" : 3323,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3321",
        "source" : "2907",
        "target" : "2929",
        "shared_name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_IGFBP2",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#001200FF",
        "name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_IGFBP2",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.501960400582008,
        "SUID" : 3321,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3319",
        "source" : "2907",
        "target" : "2925",
        "shared_name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_MEPE",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#004E00FF",
        "name" : "T0_inprenting_trial_e_E1_C1 (interacts with) T0_MEPE",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.565438190226246,
        "SUID" : 3319,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3317",
        "source" : "2905",
        "target" : "3049",
        "shared_name" : "T0_TMT_a_tijd_E1_C1 (interacts with) T0_WMHvolume",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#7B0000FF",
        "name" : "T0_TMT_a_tijd_E1_C1 (interacts with) T0_WMHvolume",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.581044131803153,
        "SUID" : 3317,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3315",
        "source" : "2905",
        "target" : "3047",
        "shared_name" : "T0_TMT_a_tijd_E1_C1 (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#320000FF",
        "name" : "T0_TMT_a_tijd_E1_C1 (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.513272900988528,
        "SUID" : 3315,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3313",
        "source" : "2905",
        "target" : "3043",
        "shared_name" : "T0_TMT_a_tijd_E1_C1 (interacts with) T0_TNFRSF14",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#670000FF",
        "name" : "T0_TMT_a_tijd_E1_C1 (interacts with) T0_TNFRSF14",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.563770706198138,
        "SUID" : 3313,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3311",
        "source" : "2905",
        "target" : "3037",
        "shared_name" : "T0_TMT_a_tijd_E1_C1 (interacts with) T0_EPHB4",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#990000FF",
        "name" : "T0_TMT_a_tijd_E1_C1 (interacts with) T0_EPHB4",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.613815913022656,
        "SUID" : 3311,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3309",
        "source" : "2905",
        "target" : "3031",
        "shared_name" : "T0_TMT_a_tijd_E1_C1 (interacts with) T0_ALCAM",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#8D0000FF",
        "name" : "T0_TMT_a_tijd_E1_C1 (interacts with) T0_ALCAM",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.597499669739591,
        "SUID" : 3309,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3307",
        "source" : "2905",
        "target" : "3029",
        "shared_name" : "T0_TMT_a_tijd_E1_C1 (interacts with) T0_TFF3",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#320000FF",
        "name" : "T0_TMT_a_tijd_E1_C1 (interacts with) T0_TFF3",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.51051926268347,
        "SUID" : 3307,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3305",
        "source" : "2905",
        "target" : "3017",
        "shared_name" : "T0_TMT_a_tijd_E1_C1 (interacts with) T0_GRN",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#4F0000FF",
        "name" : "T0_TMT_a_tijd_E1_C1 (interacts with) T0_GRN",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.540192867989097,
        "SUID" : 3305,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3303",
        "source" : "2905",
        "target" : "3015",
        "shared_name" : "T0_TMT_a_tijd_E1_C1 (interacts with) T0_PLC",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#710000FF",
        "name" : "T0_TMT_a_tijd_E1_C1 (interacts with) T0_PLC",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.572254062705837,
        "SUID" : 3303,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3301",
        "source" : "2905",
        "target" : "3013",
        "shared_name" : "T0_TMT_a_tijd_E1_C1 (interacts with) T0_LTBR",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#8D0000FF",
        "name" : "T0_TMT_a_tijd_E1_C1 (interacts with) T0_LTBR",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.597968014674192,
        "SUID" : 3301,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3299",
        "source" : "2905",
        "target" : "3011",
        "shared_name" : "T0_TMT_a_tijd_E1_C1 (interacts with) T0_Notch3",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#3C0000FF",
        "name" : "T0_TMT_a_tijd_E1_C1 (interacts with) T0_Notch3",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.522604717917006,
        "SUID" : 3299,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3297",
        "source" : "2905",
        "target" : "3005",
        "shared_name" : "T0_TMT_a_tijd_E1_C1 (interacts with) T0_CDH5",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#400000FF",
        "name" : "T0_TMT_a_tijd_E1_C1 (interacts with) T0_CDH5",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.525292726230561,
        "SUID" : 3297,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3295",
        "source" : "2905",
        "target" : "3003",
        "shared_name" : "T0_TMT_a_tijd_E1_C1 (interacts with) T0_TLT2",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#1A0000FF",
        "name" : "T0_TMT_a_tijd_E1_C1 (interacts with) T0_TLT2",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.502386278829208,
        "SUID" : 3295,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3293",
        "source" : "2905",
        "target" : "3001",
        "shared_name" : "T0_TMT_a_tijd_E1_C1 (interacts with) T0_TFPI",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#4A0000FF",
        "name" : "T0_TMT_a_tijd_E1_C1 (interacts with) T0_TFPI",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.535895662325308,
        "SUID" : 3293,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3291",
        "source" : "2905",
        "target" : "2989",
        "shared_name" : "T0_TMT_a_tijd_E1_C1 (interacts with) T0_CXCL16",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#540000FF",
        "name" : "T0_TMT_a_tijd_E1_C1 (interacts with) T0_CXCL16",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.542218885912811,
        "SUID" : 3291,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3289",
        "source" : "2905",
        "target" : "2987",
        "shared_name" : "T0_TMT_a_tijd_E1_C1 (interacts with) T0_IL6RA",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#2D0000FF",
        "name" : "T0_TMT_a_tijd_E1_C1 (interacts with) T0_IL6RA",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.505467303949204,
        "SUID" : 3289,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3287",
        "source" : "2905",
        "target" : "2981",
        "shared_name" : "T0_TMT_a_tijd_E1_C1 (interacts with) T0_AXL",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#6C0000FF",
        "name" : "T0_TMT_a_tijd_E1_C1 (interacts with) T0_AXL",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.56906160105432,
        "SUID" : 3287,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3285",
        "source" : "2905",
        "target" : "2979",
        "shared_name" : "T0_TMT_a_tijd_E1_C1 (interacts with) T0_IL1RT1",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#6C0000FF",
        "name" : "T0_TMT_a_tijd_E1_C1 (interacts with) T0_IL1RT1",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.5668177877058,
        "SUID" : 3285,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3283",
        "source" : "2905",
        "target" : "2975",
        "shared_name" : "T0_TMT_a_tijd_E1_C1 (interacts with) T0_FAS",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#540000FF",
        "name" : "T0_TMT_a_tijd_E1_C1 (interacts with) T0_FAS",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.544369947403622,
        "SUID" : 3283,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3281",
        "source" : "2905",
        "target" : "2967",
        "shared_name" : "T0_TMT_a_tijd_E1_C1 (interacts with) T0_UPAR",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#4A0000FF",
        "name" : "T0_TMT_a_tijd_E1_C1 (interacts with) T0_UPAR",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.536803000706741,
        "SUID" : 3281,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3279",
        "source" : "2905",
        "target" : "2951",
        "shared_name" : "T0_TMT_a_tijd_E1_C1 (interacts with) T0_uPA",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#450000FF",
        "name" : "T0_TMT_a_tijd_E1_C1 (interacts with) T0_uPA",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.529008330276903,
        "SUID" : 3279,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3277",
        "source" : "2905",
        "target" : "2947",
        "shared_name" : "T0_TMT_a_tijd_E1_C1 (interacts with) T0_IGFBP7",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#5D0000FF",
        "name" : "T0_TMT_a_tijd_E1_C1 (interacts with) T0_IGFBP7",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.554812804724468,
        "SUID" : 3277,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3275",
        "source" : "2905",
        "target" : "2945",
        "shared_name" : "T0_TMT_a_tijd_E1_C1 (interacts with) T0_CD93",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#9D0000FF",
        "name" : "T0_TMT_a_tijd_E1_C1 (interacts with) T0_CD93",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.615986314755055,
        "SUID" : 3275,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3273",
        "source" : "2905",
        "target" : "2943",
        "shared_name" : "T0_TMT_a_tijd_E1_C1 (interacts with) T0_IL18BP",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#910000FF",
        "name" : "T0_TMT_a_tijd_E1_C1 (interacts with) T0_IL18BP",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.605850772197497,
        "SUID" : 3273,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3271",
        "source" : "2905",
        "target" : "2939",
        "shared_name" : "T0_TMT_a_tijd_E1_C1 (interacts with) T0_CTSZ",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#370000FF",
        "name" : "T0_TMT_a_tijd_E1_C1 (interacts with) T0_CTSZ",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.515283082179318,
        "SUID" : 3271,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3269",
        "source" : "2905",
        "target" : "2937",
        "shared_name" : "T0_TMT_a_tijd_E1_C1 (interacts with) T0_RARRES2",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#370000FF",
        "name" : "T0_TMT_a_tijd_E1_C1 (interacts with) T0_RARRES2",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.51626420149389,
        "SUID" : 3269,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3267",
        "source" : "2905",
        "target" : "2933",
        "shared_name" : "T0_TMT_a_tijd_E1_C1 (interacts with) T0_KLK6",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#370000FF",
        "name" : "T0_TMT_a_tijd_E1_C1 (interacts with) T0_KLK6",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.515964821054642,
        "SUID" : 3267,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3265",
        "source" : "2905",
        "target" : "2931",
        "shared_name" : "T0_TMT_a_tijd_E1_C1 (interacts with) T0_TNFR1",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#750000FF",
        "name" : "T0_TMT_a_tijd_E1_C1 (interacts with) T0_TNFR1",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.576213752600049,
        "SUID" : 3265,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3263",
        "source" : "2905",
        "target" : "2925",
        "shared_name" : "T0_TMT_a_tijd_E1_C1 (interacts with) T0_MEPE",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#370000FF",
        "name" : "T0_TMT_a_tijd_E1_C1 (interacts with) T0_MEPE",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.516710763071594,
        "SUID" : 3263,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3261",
        "source" : "2903",
        "target" : "3049",
        "shared_name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_WMHvolume",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#007D00FF",
        "name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_WMHvolume",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.619429562091891,
        "SUID" : 3261,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3259",
        "source" : "2903",
        "target" : "3047",
        "shared_name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#005700FF",
        "name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.579185097185792,
        "SUID" : 3259,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3257",
        "source" : "2903",
        "target" : "3043",
        "shared_name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_TNFRSF14",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#009700FF",
        "name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_TNFRSF14",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.639569176905288,
        "SUID" : 3257,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3255",
        "source" : "2903",
        "target" : "3041",
        "shared_name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_ITGB2",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002A00FF",
        "name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_ITGB2",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.519855604049259,
        "SUID" : 3255,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3253",
        "source" : "2903",
        "target" : "3037",
        "shared_name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_EPHB4",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#00CE00FF",
        "name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_EPHB4",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.685182838351672,
        "SUID" : 3253,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3251",
        "source" : "2903",
        "target" : "3035",
        "shared_name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_IL2RA",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#003C00FF",
        "name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_IL2RA",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.545835641226953,
        "SUID" : 3251,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3249",
        "source" : "2903",
        "target" : "3033",
        "shared_name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_OPG",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#003200FF",
        "name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_OPG",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.529703892093459,
        "SUID" : 3249,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3247",
        "source" : "2903",
        "target" : "3031",
        "shared_name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_ALCAM",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#00B300FF",
        "name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_ALCAM",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.665641577702125,
        "SUID" : 3247,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3245",
        "source" : "2903",
        "target" : "3029",
        "shared_name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_TFF3",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#005700FF",
        "name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_TFF3",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.578649965404515,
        "SUID" : 3245,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3243",
        "source" : "2903",
        "target" : "3021",
        "shared_name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_CD163",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002700FF",
        "name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_CD163",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.515684509157778,
        "SUID" : 3243,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3241",
        "source" : "2903",
        "target" : "3019",
        "shared_name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_Gal3",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#004700FF",
        "name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_Gal3",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.558053661096997,
        "SUID" : 3241,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3239",
        "source" : "2903",
        "target" : "3017",
        "shared_name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_GRN",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#007200FF",
        "name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_GRN",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.608477409254002,
        "SUID" : 3239,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3237",
        "source" : "2903",
        "target" : "3015",
        "shared_name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_PLC",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#009D00FF",
        "name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_PLC",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.647086456671219,
        "SUID" : 3237,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3235",
        "source" : "2903",
        "target" : "3013",
        "shared_name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_LTBR",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#00B800FF",
        "name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_LTBR",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.66931080514334,
        "SUID" : 3235,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3233",
        "source" : "2903",
        "target" : "3011",
        "shared_name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_Notch3",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#005B00FF",
        "name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_Notch3",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.584953199244464,
        "SUID" : 3233,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3231",
        "source" : "2903",
        "target" : "3007",
        "shared_name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_CNTN1",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002700FF",
        "name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_CNTN1",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.516143083333609,
        "SUID" : 3231,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3229",
        "source" : "2903",
        "target" : "3005",
        "shared_name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_CDH5",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#005B00FF",
        "name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_CDH5",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.584218671698375,
        "SUID" : 3229,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3227",
        "source" : "2903",
        "target" : "3003",
        "shared_name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_TLT2",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#004700FF",
        "name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_TLT2",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.559764719677817,
        "SUID" : 3227,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3225",
        "source" : "2903",
        "target" : "3001",
        "shared_name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_TFPI",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#006300FF",
        "name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_TFPI",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.595137112220019,
        "SUID" : 3225,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3223",
        "source" : "2903",
        "target" : "2989",
        "shared_name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_CXCL16",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#007700FF",
        "name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_CXCL16",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.611222436327103,
        "SUID" : 3223,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3221",
        "source" : "2903",
        "target" : "2987",
        "shared_name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_IL6RA",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#004700FF",
        "name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_IL6RA",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.556117633898768,
        "SUID" : 3221,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3219",
        "source" : "2903",
        "target" : "2985",
        "shared_name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_RETN",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#003200FF",
        "name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_RETN",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.527720373967306,
        "SUID" : 3219,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3217",
        "source" : "2903",
        "target" : "2983",
        "shared_name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_TRAP",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#001200FF",
        "name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_TRAP",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.500197788604287,
        "SUID" : 3217,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3215",
        "source" : "2903",
        "target" : "2981",
        "shared_name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_AXL",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#008D00FF",
        "name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_AXL",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.629357442976491,
        "SUID" : 3215,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3213",
        "source" : "2903",
        "target" : "2979",
        "shared_name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_IL1RT1",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#008D00FF",
        "name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_IL1RT1",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.631353098820685,
        "SUID" : 3213,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3211",
        "source" : "2903",
        "target" : "2977",
        "shared_name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_MMP2",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002300FF",
        "name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_MMP2",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.513227424945403,
        "SUID" : 3211,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3209",
        "source" : "2903",
        "target" : "2975",
        "shared_name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_FAS",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#007700FF",
        "name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_FAS",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.612290762915836,
        "SUID" : 3209,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3207",
        "source" : "2903",
        "target" : "2971",
        "shared_name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_TNFSF13B",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002A00FF",
        "name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_TNFSF13B",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.518609764010461,
        "SUID" : 3207,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3205",
        "source" : "2903",
        "target" : "2969",
        "shared_name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_PRTN3",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002700FF",
        "name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_PRTN3",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.516530133861148,
        "SUID" : 3205,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3203",
        "source" : "2903",
        "target" : "2967",
        "shared_name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_UPAR",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#007200FF",
        "name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_UPAR",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.610645884354473,
        "SUID" : 3203,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3201",
        "source" : "2903",
        "target" : "2965",
        "shared_name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_OPN",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#003900FF",
        "name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_OPN",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.537645685299121,
        "SUID" : 3201,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3199",
        "source" : "2903",
        "target" : "2961",
        "shared_name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_PGLYRP1",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#003900FF",
        "name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_PGLYRP1",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.540778527390907,
        "SUID" : 3199,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3197",
        "source" : "2903",
        "target" : "2955",
        "shared_name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_SHPS1",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002A00FF",
        "name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_SHPS1",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.521328327265234,
        "SUID" : 3197,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3195",
        "source" : "2903",
        "target" : "2953",
        "shared_name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_CCL15",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002000FF",
        "name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_CCL15",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.505443667225935,
        "SUID" : 3195,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3193",
        "source" : "2903",
        "target" : "2951",
        "shared_name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_uPA",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#005B00FF",
        "name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_uPA",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.587130785825252,
        "SUID" : 3193,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3191",
        "source" : "2903",
        "target" : "2949",
        "shared_name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_EGFR",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#003200FF",
        "name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_EGFR",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.530218872218967,
        "SUID" : 3191,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3189",
        "source" : "2903",
        "target" : "2947",
        "shared_name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_IGFBP7",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#008D00FF",
        "name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_IGFBP7",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.629642511207067,
        "SUID" : 3189,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3187",
        "source" : "2903",
        "target" : "2945",
        "shared_name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_CD93",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#00C800FF",
        "name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_CD93",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.683332143590619,
        "SUID" : 3187,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3185",
        "source" : "2903",
        "target" : "2943",
        "shared_name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_IL18BP",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#00C300FF",
        "name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_IL18BP",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.678025768370092,
        "SUID" : 3185,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3183",
        "source" : "2903",
        "target" : "2939",
        "shared_name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_CTSZ",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#005700FF",
        "name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_CTSZ",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.582095190375761,
        "SUID" : 3183,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3181",
        "source" : "2903",
        "target" : "2937",
        "shared_name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_RARRES2",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#005F00FF",
        "name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_RARRES2",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.589344269932412,
        "SUID" : 3181,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3179",
        "source" : "2903",
        "target" : "2935",
        "shared_name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_ICAM2",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#003900FF",
        "name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_ICAM2",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.541248835793647,
        "SUID" : 3179,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3177",
        "source" : "2903",
        "target" : "2933",
        "shared_name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_KLK6",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#005100FF",
        "name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_KLK6",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.57254764726074,
        "SUID" : 3177,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3175",
        "source" : "2903",
        "target" : "2931",
        "shared_name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_TNFR1",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#00A300FF",
        "name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_TNFR1",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.650185672097405,
        "SUID" : 3175,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3173",
        "source" : "2903",
        "target" : "2929",
        "shared_name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_IGFBP2",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002300FF",
        "name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_IGFBP2",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.509709285146378,
        "SUID" : 3173,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3171",
        "source" : "2903",
        "target" : "2925",
        "shared_name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_MEPE",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#005100FF",
        "name" : "T0_uitgestelde_herinnering_E1_C1 (interacts with) T0_MEPE",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.573170411738026,
        "SUID" : 3171,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3169",
        "source" : "2901",
        "target" : "3049",
        "shared_name" : "T0_Stroop_III_E1_C1 (interacts with) T0_WMHvolume",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#1A0000FF",
        "name" : "T0_Stroop_III_E1_C1 (interacts with) T0_WMHvolume",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.503438542794976,
        "SUID" : 3169,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3167",
        "source" : "2899",
        "target" : "3043",
        "shared_name" : "T0_Dieren_E1_C1 (interacts with) T0_TNFRSF14",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#004700FF",
        "name" : "T0_Dieren_E1_C1 (interacts with) T0_TNFRSF14",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.559391996963841,
        "SUID" : 3167,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3165",
        "source" : "2899",
        "target" : "3037",
        "shared_name" : "T0_Dieren_E1_C1 (interacts with) T0_EPHB4",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#005100FF",
        "name" : "T0_Dieren_E1_C1 (interacts with) T0_EPHB4",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.56920031869704,
        "SUID" : 3165,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3163",
        "source" : "2899",
        "target" : "3031",
        "shared_name" : "T0_Dieren_E1_C1 (interacts with) T0_ALCAM",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#004000FF",
        "name" : "T0_Dieren_E1_C1 (interacts with) T0_ALCAM",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.549328393475724,
        "SUID" : 3163,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3161",
        "source" : "2899",
        "target" : "3029",
        "shared_name" : "T0_Dieren_E1_C1 (interacts with) T0_TFF3",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002000FF",
        "name" : "T0_Dieren_E1_C1 (interacts with) T0_TFF3",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.504739716036496,
        "SUID" : 3161,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3159",
        "source" : "2899",
        "target" : "3017",
        "shared_name" : "T0_Dieren_E1_C1 (interacts with) T0_GRN",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002A00FF",
        "name" : "T0_Dieren_E1_C1 (interacts with) T0_GRN",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.520486912860349,
        "SUID" : 3159,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3157",
        "source" : "2899",
        "target" : "3015",
        "shared_name" : "T0_Dieren_E1_C1 (interacts with) T0_PLC",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#004A00FF",
        "name" : "T0_Dieren_E1_C1 (interacts with) T0_PLC",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.560287434291533,
        "SUID" : 3157,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3155",
        "source" : "2899",
        "target" : "3013",
        "shared_name" : "T0_Dieren_E1_C1 (interacts with) T0_LTBR",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#004A00FF",
        "name" : "T0_Dieren_E1_C1 (interacts with) T0_LTBR",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.560997340505973,
        "SUID" : 3155,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3153",
        "source" : "2899",
        "target" : "2989",
        "shared_name" : "T0_Dieren_E1_C1 (interacts with) T0_CXCL16",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002E00FF",
        "name" : "T0_Dieren_E1_C1 (interacts with) T0_CXCL16",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.52409187144303,
        "SUID" : 3153,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3151",
        "source" : "2899",
        "target" : "2981",
        "shared_name" : "T0_Dieren_E1_C1 (interacts with) T0_AXL",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002000FF",
        "name" : "T0_Dieren_E1_C1 (interacts with) T0_AXL",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.506748122623096,
        "SUID" : 3151,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3149",
        "source" : "2899",
        "target" : "2979",
        "shared_name" : "T0_Dieren_E1_C1 (interacts with) T0_IL1RT1",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002A00FF",
        "name" : "T0_Dieren_E1_C1 (interacts with) T0_IL1RT1",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.520736365243972,
        "SUID" : 3149,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3147",
        "source" : "2899",
        "target" : "2975",
        "shared_name" : "T0_Dieren_E1_C1 (interacts with) T0_FAS",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002A00FF",
        "name" : "T0_Dieren_E1_C1 (interacts with) T0_FAS",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.521327563792259,
        "SUID" : 3147,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3145",
        "source" : "2899",
        "target" : "2967",
        "shared_name" : "T0_Dieren_E1_C1 (interacts with) T0_UPAR",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#003900FF",
        "name" : "T0_Dieren_E1_C1 (interacts with) T0_UPAR",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.538597352526949,
        "SUID" : 3145,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3143",
        "source" : "2899",
        "target" : "2947",
        "shared_name" : "T0_Dieren_E1_C1 (interacts with) T0_IGFBP7",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#004200FF",
        "name" : "T0_Dieren_E1_C1 (interacts with) T0_IGFBP7",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.551344966725431,
        "SUID" : 3143,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3141",
        "source" : "2899",
        "target" : "2945",
        "shared_name" : "T0_Dieren_E1_C1 (interacts with) T0_CD93",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#004700FF",
        "name" : "T0_Dieren_E1_C1 (interacts with) T0_CD93",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.55595419876848,
        "SUID" : 3141,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3139",
        "source" : "2899",
        "target" : "2943",
        "shared_name" : "T0_Dieren_E1_C1 (interacts with) T0_IL18BP",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#004E00FF",
        "name" : "T0_Dieren_E1_C1 (interacts with) T0_IL18BP",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.56800611930939,
        "SUID" : 3139,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3137",
        "source" : "2899",
        "target" : "2939",
        "shared_name" : "T0_Dieren_E1_C1 (interacts with) T0_CTSZ",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#001200FF",
        "name" : "T0_Dieren_E1_C1 (interacts with) T0_CTSZ",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.502471421359672,
        "SUID" : 3137,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3135",
        "source" : "2899",
        "target" : "2937",
        "shared_name" : "T0_Dieren_E1_C1 (interacts with) T0_RARRES2",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002E00FF",
        "name" : "T0_Dieren_E1_C1 (interacts with) T0_RARRES2",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.525354307313452,
        "SUID" : 3135,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3133",
        "source" : "2899",
        "target" : "2931",
        "shared_name" : "T0_Dieren_E1_C1 (interacts with) T0_TNFR1",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#004700FF",
        "name" : "T0_Dieren_E1_C1 (interacts with) T0_TNFR1",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.559243053436348,
        "SUID" : 3133,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3131",
        "source" : "2897",
        "target" : "3049",
        "shared_name" : "T0_LDST_E1_C1 (interacts with) T0_WMHvolume",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#003C00FF",
        "name" : "T0_LDST_E1_C1 (interacts with) T0_WMHvolume",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.545299356054207,
        "SUID" : 3131,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3129",
        "source" : "2897",
        "target" : "3047",
        "shared_name" : "T0_LDST_E1_C1 (interacts with) T0_PWV",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#003C00FF",
        "name" : "T0_LDST_E1_C1 (interacts with) T0_PWV",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.543095382683857,
        "SUID" : 3129,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3127",
        "source" : "2897",
        "target" : "3043",
        "shared_name" : "T0_LDST_E1_C1 (interacts with) T0_TNFRSF14",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#006D00FF",
        "name" : "T0_LDST_E1_C1 (interacts with) T0_TNFRSF14",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.603053006972051,
        "SUID" : 3127,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3125",
        "source" : "2897",
        "target" : "3037",
        "shared_name" : "T0_LDST_E1_C1 (interacts with) T0_EPHB4",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#009200FF",
        "name" : "T0_LDST_E1_C1 (interacts with) T0_EPHB4",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.635175143468903,
        "SUID" : 3125,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3123",
        "source" : "2897",
        "target" : "3035",
        "shared_name" : "T0_LDST_E1_C1 (interacts with) T0_IL2RA",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002000FF",
        "name" : "T0_LDST_E1_C1 (interacts with) T0_IL2RA",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.508522011288322,
        "SUID" : 3123,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3121",
        "source" : "2897",
        "target" : "3033",
        "shared_name" : "T0_LDST_E1_C1 (interacts with) T0_OPG",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#001200FF",
        "name" : "T0_LDST_E1_C1 (interacts with) T0_OPG",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.502350671515195,
        "SUID" : 3121,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3119",
        "source" : "2897",
        "target" : "3031",
        "shared_name" : "T0_LDST_E1_C1 (interacts with) T0_ALCAM",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#007D00FF",
        "name" : "T0_LDST_E1_C1 (interacts with) T0_ALCAM",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.615743492746243,
        "SUID" : 3119,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3117",
        "source" : "2897",
        "target" : "3029",
        "shared_name" : "T0_LDST_E1_C1 (interacts with) T0_TFF3",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#003C00FF",
        "name" : "T0_LDST_E1_C1 (interacts with) T0_TFF3",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.54511624055076,
        "SUID" : 3117,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3115",
        "source" : "2897",
        "target" : "3019",
        "shared_name" : "T0_LDST_E1_C1 (interacts with) T0_Gal3",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002E00FF",
        "name" : "T0_LDST_E1_C1 (interacts with) T0_Gal3",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.523614252316795,
        "SUID" : 3115,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3113",
        "source" : "2897",
        "target" : "3017",
        "shared_name" : "T0_LDST_E1_C1 (interacts with) T0_GRN",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#005100FF",
        "name" : "T0_LDST_E1_C1 (interacts with) T0_GRN",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.56949872071679,
        "SUID" : 3113,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3111",
        "source" : "2897",
        "target" : "3015",
        "shared_name" : "T0_LDST_E1_C1 (interacts with) T0_PLC",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#007200FF",
        "name" : "T0_LDST_E1_C1 (interacts with) T0_PLC",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.608085939253901,
        "SUID" : 3111,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3109",
        "source" : "2897",
        "target" : "3013",
        "shared_name" : "T0_LDST_E1_C1 (interacts with) T0_LTBR",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#008300FF",
        "name" : "T0_LDST_E1_C1 (interacts with) T0_LTBR",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.622264417835979,
        "SUID" : 3109,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3107",
        "source" : "2897",
        "target" : "3011",
        "shared_name" : "T0_LDST_E1_C1 (interacts with) T0_Notch3",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#003C00FF",
        "name" : "T0_LDST_E1_C1 (interacts with) T0_Notch3",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.543833594926487,
        "SUID" : 3107,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3105",
        "source" : "2897",
        "target" : "3005",
        "shared_name" : "T0_LDST_E1_C1 (interacts with) T0_CDH5",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#003900FF",
        "name" : "T0_LDST_E1_C1 (interacts with) T0_CDH5",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.539449586178134,
        "SUID" : 3105,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3103",
        "source" : "2897",
        "target" : "3003",
        "shared_name" : "T0_LDST_E1_C1 (interacts with) T0_TLT2",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002700FF",
        "name" : "T0_LDST_E1_C1 (interacts with) T0_TLT2",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.517886614794646,
        "SUID" : 3103,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3101",
        "source" : "2897",
        "target" : "3001",
        "shared_name" : "T0_LDST_E1_C1 (interacts with) T0_TFPI",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#004000FF",
        "name" : "T0_LDST_E1_C1 (interacts with) T0_TFPI",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.548661728700404,
        "SUID" : 3101,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3099",
        "source" : "2897",
        "target" : "2989",
        "shared_name" : "T0_LDST_E1_C1 (interacts with) T0_CXCL16",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#005100FF",
        "name" : "T0_LDST_E1_C1 (interacts with) T0_CXCL16",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.57252271377031,
        "SUID" : 3099,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3097",
        "source" : "2897",
        "target" : "2987",
        "shared_name" : "T0_LDST_E1_C1 (interacts with) T0_IL6RA",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002000FF",
        "name" : "T0_LDST_E1_C1 (interacts with) T0_IL6RA",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.507480037587193,
        "SUID" : 3097,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3095",
        "source" : "2897",
        "target" : "2981",
        "shared_name" : "T0_LDST_E1_C1 (interacts with) T0_AXL",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#005400FF",
        "name" : "T0_LDST_E1_C1 (interacts with) T0_AXL",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.577606758228832,
        "SUID" : 3095,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3093",
        "source" : "2897",
        "target" : "2979",
        "shared_name" : "T0_LDST_E1_C1 (interacts with) T0_IL1RT1",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#005B00FF",
        "name" : "T0_LDST_E1_C1 (interacts with) T0_IL1RT1",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.583918589119872,
        "SUID" : 3093,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3091",
        "source" : "2897",
        "target" : "2975",
        "shared_name" : "T0_LDST_E1_C1 (interacts with) T0_FAS",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#005100FF",
        "name" : "T0_LDST_E1_C1 (interacts with) T0_FAS",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.572191645085072,
        "SUID" : 3091,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3089",
        "source" : "2897",
        "target" : "2967",
        "shared_name" : "T0_LDST_E1_C1 (interacts with) T0_UPAR",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#005400FF",
        "name" : "T0_LDST_E1_C1 (interacts with) T0_UPAR",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.577410449055867,
        "SUID" : 3089,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3087",
        "source" : "2897",
        "target" : "2965",
        "shared_name" : "T0_LDST_E1_C1 (interacts with) T0_OPN",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002300FF",
        "name" : "T0_LDST_E1_C1 (interacts with) T0_OPN",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.509532118506748,
        "SUID" : 3087,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3085",
        "source" : "2897",
        "target" : "2961",
        "shared_name" : "T0_LDST_E1_C1 (interacts with) T0_PGLYRP1",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002000FF",
        "name" : "T0_LDST_E1_C1 (interacts with) T0_PGLYRP1",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.506163359952358,
        "SUID" : 3085,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3083",
        "source" : "2897",
        "target" : "2951",
        "shared_name" : "T0_LDST_E1_C1 (interacts with) T0_uPA",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#003900FF",
        "name" : "T0_LDST_E1_C1 (interacts with) T0_uPA",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.540924243252136,
        "SUID" : 3083,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3081",
        "source" : "2897",
        "target" : "2947",
        "shared_name" : "T0_LDST_E1_C1 (interacts with) T0_IGFBP7",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#006300FF",
        "name" : "T0_LDST_E1_C1 (interacts with) T0_IGFBP7",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.593922960575918,
        "SUID" : 3081,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3079",
        "source" : "2897",
        "target" : "2945",
        "shared_name" : "T0_LDST_E1_C1 (interacts with) T0_CD93",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#008D00FF",
        "name" : "T0_LDST_E1_C1 (interacts with) T0_CD93",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.629222659407963,
        "SUID" : 3079,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3077",
        "source" : "2897",
        "target" : "2943",
        "shared_name" : "T0_LDST_E1_C1 (interacts with) T0_IL18BP",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#008D00FF",
        "name" : "T0_LDST_E1_C1 (interacts with) T0_IL18BP",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.630259742036214,
        "SUID" : 3077,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3075",
        "source" : "2897",
        "target" : "2939",
        "shared_name" : "T0_LDST_E1_C1 (interacts with) T0_CTSZ",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#004000FF",
        "name" : "T0_LDST_E1_C1 (interacts with) T0_CTSZ",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.546453574365788,
        "SUID" : 3075,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3073",
        "source" : "2897",
        "target" : "2937",
        "shared_name" : "T0_LDST_E1_C1 (interacts with) T0_RARRES2",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#004700FF",
        "name" : "T0_LDST_E1_C1 (interacts with) T0_RARRES2",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.559274791404886,
        "SUID" : 3073,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3071",
        "source" : "2897",
        "target" : "2933",
        "shared_name" : "T0_LDST_E1_C1 (interacts with) T0_KLK6",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#002E00FF",
        "name" : "T0_LDST_E1_C1 (interacts with) T0_KLK6",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.527382553400591,
        "SUID" : 3071,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3069",
        "source" : "2897",
        "target" : "2931",
        "shared_name" : "T0_LDST_E1_C1 (interacts with) T0_TNFR1",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#007200FF",
        "name" : "T0_LDST_E1_C1 (interacts with) T0_TNFR1",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.609649409063319,
        "SUID" : 3069,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3067",
        "source" : "2897",
        "target" : "2925",
        "shared_name" : "T0_LDST_E1_C1 (interacts with) T0_MEPE",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#003200FF",
        "name" : "T0_LDST_E1_C1 (interacts with) T0_MEPE",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : -0.527751756197959,
        "SUID" : 3067,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3065",
        "source" : "2895",
        "target" : "3043",
        "shared_name" : "T0_4m_tijd_a_E1_C1 (interacts with) T0_TNFRSF14",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#1A0000FF",
        "name" : "T0_4m_tijd_a_E1_C1 (interacts with) T0_TNFRSF14",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.503239646950612,
        "SUID" : 3065,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3063",
        "source" : "2893",
        "target" : "3043",
        "shared_name" : "T0_4m_tijd_b_E1_C1 (interacts with) T0_TNFRSF14",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#3C0000FF",
        "name" : "T0_4m_tijd_b_E1_C1 (interacts with) T0_TNFRSF14",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.52299046199128,
        "SUID" : 3063,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3061",
        "source" : "2893",
        "target" : "3015",
        "shared_name" : "T0_4m_tijd_b_E1_C1 (interacts with) T0_PLC",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#320000FF",
        "name" : "T0_4m_tijd_b_E1_C1 (interacts with) T0_PLC",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.512884525972563,
        "SUID" : 3061,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3059",
        "source" : "2893",
        "target" : "2997",
        "shared_name" : "T0_4m_tijd_b_E1_C1 (interacts with) T0_GDF15",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#1A0000FF",
        "name" : "T0_4m_tijd_b_E1_C1 (interacts with) T0_GDF15",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.500112979023908,
        "SUID" : 3059,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3057",
        "source" : "2893",
        "target" : "2967",
        "shared_name" : "T0_4m_tijd_b_E1_C1 (interacts with) T0_UPAR",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#320000FF",
        "name" : "T0_4m_tijd_b_E1_C1 (interacts with) T0_UPAR",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.512224894985132,
        "SUID" : 3057,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3055",
        "source" : "2893",
        "target" : "2947",
        "shared_name" : "T0_4m_tijd_b_E1_C1 (interacts with) T0_IGFBP7",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#370000FF",
        "name" : "T0_4m_tijd_b_E1_C1 (interacts with) T0_IGFBP7",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.516691003927666,
        "SUID" : 3055,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3053",
        "source" : "2893",
        "target" : "2937",
        "shared_name" : "T0_4m_tijd_b_E1_C1 (interacts with) T0_RARRES2",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#320000FF",
        "name" : "T0_4m_tijd_b_E1_C1 (interacts with) T0_RARRES2",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.510225462553698,
        "SUID" : 3053,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3051",
        "source" : "2893",
        "target" : "2931",
        "shared_name" : "T0_4m_tijd_b_E1_C1 (interacts with) T0_TNFR1",
        "lty" : "solid",
        "shared_interaction" : "interacts with",
        "color" : "#2D0000FF",
        "name" : "T0_4m_tijd_b_E1_C1 (interacts with) T0_TNFR1",
        "interaction" : "interacts with",
        "width" : 1,
        "weight" : 0.504672889711778,
        "SUID" : 3051,
        "labelcex" : 0.514939204213098,
        "labelcolor" : "black",
        "selected" : false
      },
      "selected" : false
    } ]
  }
}}